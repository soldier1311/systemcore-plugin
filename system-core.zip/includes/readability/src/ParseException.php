<?php

namespace andreskrey\Readability;

class ParseException extends \Exception
{
}
