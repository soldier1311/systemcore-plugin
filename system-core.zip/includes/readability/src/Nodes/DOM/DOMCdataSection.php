<?php

namespace andreskrey\Readability\Nodes\DOM;

use andreskrey\Readability\Nodes\NodeTrait;

class DOMCdataSection extends \DOMCdataSection
{
    use NodeTrait;
}
