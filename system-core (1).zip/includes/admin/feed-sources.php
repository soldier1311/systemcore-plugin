<?php
if (!defined('ABSPATH')) exit;

global $wpdb;
$table = $wpdb->prefix . 'systemcore_feed_sources';

/* Load all sources */
$sources = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");
$base = admin_url('admin.php?page=systemcore-dashboard&tab=feeds');
?>

<div class="sc-page">

    <h1 class="sc-title">Feed Sources</h1>

    <!-- ACTION BAR -->
    <div class="sc-card sc-mt-20">
        <div style="display:flex; justify-content: space-between; align-items:center;">
            <h2 class="sc-card-title" style="margin:0;">Manage Feed Sources</h2>

            <button class="button button-primary" id="sc-open-new-source">
                + Add New Source
            </button>
        </div>

        <p style="margin-top:10px;">
            Add, edit or delete your feed sources. All operations happen instantly via AJAX.
        </p>
    </div>

    <!-- LIST -->
    <div class="sc-card sc-mt-20">
        <h2 class="sc-card-title">Active Sources</h2>

        <div class="sc-grid sc-grid-3" id="sc-feed-list">

            <?php foreach ($sources as $src): ?>
                <?php
                $favicon = "https://www.google.com/s2/favicons?sz=64&domain=" . urlencode($src->feed_url);
                ?>
                <div class="sc-card sc-feed-item" data-id="<?php echo $src->id; ?>">

                    <div class="sc-feed-card-header">
                        <div class="sc-feed-name"><?php echo esc_html($src->source_name); ?></div>
                        <img src="<?php echo esc_url($favicon); ?>" class="sc-feed-logo">
                    </div>

                    <div class="sc-feed-url"><?php echo esc_html($src->feed_url); ?></div>

                    <div class="sc-feed-actions">
                        <button class="button button-small sc-btn-edit" data-id="<?php echo $src->id; ?>">
                            Edit
                        </button>

                        <button class="button button-small sc-btn-delete" data-id="<?php echo $src->id; ?>">
                            Delete
                        </button>
                    </div>

                </div>
            <?php endforeach; ?>

        </div>
    </div>

</div>

<!-- ===========================================
     MODAL POPUP
=========================================== -->
<div id="sc-modal" class="sc-modal">
    <div class="sc-modal-content">
        
        <h2 id="sc-modal-title">Add New Source</h2>

        <form id="sc-source-form">
            <input type="hidden" name="id" id="sc-source-id" value="0">

            <div class="sc-field">
                <label>Source Name</label>
                <input type="text" id="sc-source-name" name="source_name" required>
            </div>

            <div class="sc-field">
                <label>Feed URL</label>
                <input type="text" id="sc-source-url" name="feed_url" required>
            </div>

            <button type="submit" class="button button-primary">Save</button>
            <button type="button" class="button sc-close-modal">Cancel</button>

            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('systemcore_admin_nonce'); ?>">
            <input type="hidden" name="action" value="systemcore_save_feed_source">
        </form>

    </div>
</div>
