<?php if (!defined('ABSPATH')) exit;

global $wpdb;
$table_queue = $wpdb->prefix . 'systemcore_queue';
$table_feeds = $wpdb->prefix . 'systemcore_feed_sources';

// Count KPIs
$total   = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_queue");
$pending = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_queue WHERE status = 'pending'");
$done    = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_queue WHERE status = 'done'");
$feeds   = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_feeds");
?>

<div class="sc-page">

    <h1 class="sc-title">SystemCore Queue</h1>

    <!-- KPI GRID -->
    <div class="sc-grid sc-grid-4 sc-mt-20">

        <div class="sc-card">
            <div class="sc-kpi-title">Total Items</div>
            <div class="sc-kpi-value"><?php echo $total; ?></div>
        </div>

        <div class="sc-card">
            <div class="sc-kpi-title">Pending</div>
            <div class="sc-kpi-value sc-orange"><?php echo $pending; ?></div>
        </div>

        <div class="sc-card">
            <div class="sc-kpi-title">Processed</div>
            <div class="sc-kpi-value sc-green"><?php echo $done; ?></div>
        </div>

        <div class="sc-card">
            <div class="sc-kpi-title">Feed Sources</div>
            <div class="sc-kpi-value"><?php echo $feeds; ?></div>
        </div>

    </div>


    <!-- SEARCH / ACTIONS -->
    <div class="sc-card sc-mt-25">

        <h2 class="sc-card-title">Search & Actions</h2>

        <div style="display:flex; gap:10px; align-items:center;">
            <input type="search" id="sc-queue-search" placeholder="Search URL…" class="regular-text" style="flex:1;">
            <button class="button" id="sc-queue-refresh">Refresh</button>
        </div>

    </div>


    <!-- TABLE WRAPPER -->
    <div class="sc-card sc-mt-25">

        <h2 class="sc-card-title">Queue List</h2>

        <table class="sc-table" id="sc-queue-table">
            <thead>
                <tr>
                    <th width="60">ID</th>
                    <th width="180">Feed</th>
                    <th>URL</th>
                    <th width="140">Created</th>
                    <th width="100">Status</th>
                    <th width="130">Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="6">Loading queue…</td></tr>
            </tbody>
        </table>

    </div>

</div>

<script>
document.addEventListener("DOMContentLoaded", function () {

    function timeAgo(dateString) {
        if (!dateString) return "";
        const now = new Date();
        const past = new Date(dateString);
        const diff = Math.floor((now - past) / 1000);

        if (diff < 60) return diff + "s ago";
        if (diff < 3600) return Math.floor(diff / 60) + "m ago";
        if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
        if (diff < 2592000) return Math.floor(diff / 86400) + "d ago";
        if (diff < 31104000) return Math.floor(diff / 2592000) + "mo ago";

        return Math.floor(diff / 31104000) + "y ago";
    }

    function loadQueue() {
        const search = document.getElementById('sc-queue-search').value;

        jQuery.post(ajaxurl, {
            action: "systemcore_load_queue_new",
            search: search
        }, function (res) {

            let tbody = document.querySelector("#sc-queue-table tbody");

            if (!res || !Array.isArray(res) || res.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6">No results found.</td></tr>';
                return;
            }

            let html = "";
            res.forEach(row => {
                html += `
                <tr>
                    <td>${row.id}</td>
                    <td>${row.feed_name || 'Unknown'}</td>
                    <td><a href="${row.url}" target="_blank">${row.url}</a></td>
                    <td>${row.created_at ? timeAgo(row.created_at) : ''}</td>
                    <td>${row.status}</td>
                    <td>
                        <button class="button button-small sc-btn-view" data-link="${row.url}">View</button>
                        <button class="button button-small sc-btn-delete" data-id="${row.id}">Delete</button>
                    </td>
                </tr>`;
            });

            tbody.innerHTML = html;
        });
    }

    function deleteItem(id) {
        if (!confirm("Delete this queue item?")) return;
        jQuery.post(ajaxurl, { action:"systemcore_delete_queue_item", id:id }, function (res) {
            loadQueue();
        });
    }

    // Actions
    document.getElementById("sc-queue-refresh").addEventListener("click", loadQueue);
    document.getElementById("sc-queue-search").addEventListener("keyup", loadQueue);

    jQuery(document).on("click", ".sc-btn-delete", function () {
        deleteItem(jQuery(this).data("id"));
    });

    jQuery(document).on("click", ".sc-btn-view", function () {
        window.open(jQuery(this).data("link"), "_blank");
    });

    loadQueue();
});
</script>
