<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

/**
 * Helper: safe table exists check
 */
if (!function_exists('systemcore_table_exists')) {
    function systemcore_table_exists($table_name) {
        global $wpdb;
        if (empty($table_name)) {
            return false;
        }
        $like  = $wpdb->prepare('SHOW TABLES LIKE %s', $table_name);
        $found = $wpdb->get_var($like);
        return ($found === $table_name);
    }
}

/**
 * Helper: check if column exists in table (INFORMATION_SCHEMA)
 */
if (!function_exists('systemcore_column_exists')) {
    function systemcore_column_exists($table_name, $column_name) {
        global $wpdb;
        if (empty($table_name) || empty($column_name)) {
            return false;
        }

        $sql = $wpdb->prepare("
            SELECT COUNT(*)
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME   = %s
              AND COLUMN_NAME  = %s
        ", $table_name, $column_name);

        return (int) $wpdb->get_var($sql) > 0;
    }
}

/* ============================================================
 *  BASIC TABLE NAMES
 * ============================================================ */
$queue_table = $wpdb->prefix . 'systemcore_queue';
$logs_table  = $wpdb->prefix . 'systemcore_logs';
$feeds_table = $wpdb->prefix . 'systemcore_feed_sources';

/* ============================================================
 *  QUEUE STATS (USING status FIELD: pending / done)
 * ============================================================ */
$queue_total   = 0;
$queue_pending = 0;
$queue_done    = 0;

if (systemcore_table_exists($queue_table)) {
    $queue_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$queue_table}");

    // pending
    $queue_pending = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$queue_table} WHERE status = %s",
        'pending'
    ));

    // done
    $queue_done = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$queue_table} WHERE status = %s",
        'done'
    ));
}

/* ============================================================
 *  FEED SOURCES STATS (feed_type OPTIONAL)
 * ============================================================ */
$feed_total = 0;
$feed_rss   = 0;
$feed_xml   = 0;
$feed_json  = 0;

if (systemcore_table_exists($feeds_table)) {

    $has_feed_type = systemcore_column_exists($feeds_table, 'feed_type');

    if ($has_feed_type) {
        $rows = $wpdb->get_results("SELECT feed_type, COUNT(*) AS cnt FROM {$feeds_table} GROUP BY feed_type");
        if ($rows) {
            foreach ($rows as $row) {
                $type = strtolower(trim($row->feed_type));
                $cnt  = (int) $row->cnt;

                $feed_total += $cnt;

                if ($type === 'xml') {
                    $feed_xml += $cnt;
                } elseif ($type === 'json') {
                    $feed_json += $cnt;
                } else {
                    // treat unknown / rss as RSS
                    $feed_rss += $cnt;
                }
            }
        }
    } else {
        // Legacy schema: no feed_type column -> everything counted as RSS
        $feed_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$feeds_table}");
        $feed_rss   = $feed_total;
        $feed_xml   = 0;
        $feed_json  = 0;
    }
}

/* ============================================================
 *  POSTS PUBLISHED BY SYSTEMCORE
 * ============================================================ */
$today_published = 0;
$all_published   = 0;

$posts_table = $wpdb->posts;
$meta_table  = $wpdb->postmeta;

$today = current_time('Y-m-d');

$sql_today = $wpdb->prepare("
    SELECT COUNT(DISTINCT p.ID)
    FROM {$posts_table} AS p
    INNER JOIN {$meta_table} AS m
        ON m.post_id = p.ID AND m.meta_key = %s
    WHERE p.post_type   = 'post'
      AND p.post_status = 'publish'
      AND p.post_date  >= %s
", '_systemcore_source_url', $today . ' 00:00:00');

$today_published = (int) $wpdb->get_var($sql_today);

$sql_all = "
    SELECT COUNT(DISTINCT p.ID)
    FROM {$posts_table} AS p
    INNER JOIN {$meta_table} AS m
        ON m.post_id = p.ID AND m.meta_key = '_systemcore_source_url'
    WHERE p.post_type   = 'post'
      AND p.post_status = 'publish'
";
$all_published = (int) $wpdb->get_var($sql_all);

/* ============================================================
 *  LOGS STATS
 * ============================================================ */
$logs_total      = 0;
$logs_info       = 0;
$logs_warning    = 0;
$logs_error      = 0;
$logs_debug      = 0;
$last_log_time   = '—';
$last_error_time = '—';
$last_cron_run   = '—';

if (systemcore_table_exists($logs_table)) {

    $logs_total   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$logs_table}");
    $logs_info    = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$logs_table} WHERE level = 'info'");
    $logs_warning = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$logs_table} WHERE level = 'warning'");
    $logs_error   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$logs_table} WHERE level = 'error'");
    $logs_debug   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$logs_table} WHERE level = 'debug'");

    $last_log_time = $wpdb->get_var("SELECT created_at FROM {$logs_table} ORDER BY id DESC LIMIT 1") ?: '—';
    $last_error_time = $wpdb->get_var("
        SELECT created_at FROM {$logs_table}
        WHERE level = 'error'
        ORDER BY id DESC
        LIMIT 1
    ") ?: '—';

    // last cron run (message starts with "CRON: systemcore_cron_runner completed")
    $last_cron_run = $wpdb->get_var("
        SELECT created_at
        FROM {$logs_table}
        WHERE message LIKE 'CRON: systemcore_cron_runner completed%'
        ORDER BY id DESC
        LIMIT 1
    ") ?: '—';
}

/* ============================================================
 *  CRON STATUS
 * ============================================================ */
$cron_disabled   = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;
$cron_next       = wp_next_scheduled('systemcore_cron_runner');
$cron_status     = $cron_disabled ? 'Disabled (DISABLE_WP_CRON)' : ($cron_next ? 'Scheduled' : 'Not Scheduled');
$cron_next_human = $cron_next ? date_i18n('Y-m-d H:i:s', $cron_next) : '—';

/* ============================================================
 *  AI ENGINE OVERVIEW (READ FROM systemcore_ai_settings)
 * ============================================================ */
$ai_settings = get_option('systemcore_ai_settings', []);

$ai_enabled    = (isset($ai_settings['enabled']) ? $ai_settings['enabled'] === 'yes' : true);
$ai_has_key    = !empty(trim((string) ($ai_settings['api_key'] ?? '')));
$ai_connected  = $ai_enabled && $ai_has_key;

$ai_model      = $ai_settings['model']             ?? 'gpt-4o-mini';
$ai_lang       = $ai_settings['default_language']  ?? 'auto';
$ai_style      = $ai_settings['writing_style']     ?? 'tech_journalism';
$ai_rewrite    = (int) ($ai_settings['rewrite_strength']  ?? 70);
$ai_target_wc  = (int) ($ai_settings['target_word_count'] ?? 600);
$ai_title_len  = (int) ($ai_settings['title_length']      ?? 60);
$ai_meta_len   = (int) ($ai_settings['meta_length']       ?? 160);
$ai_seo_mode   = $ai_settings['seo_mode']          ?? 'advanced';

/* ============================================================
 *  PUBLISHER OVERVIEW (READ FROM systemcore_publisher_settings)
 * ============================================================ */
if (function_exists('systemcore_get_publisher_settings')) {
    $pub_options = systemcore_get_publisher_settings();
} else {
    $pub_options = get_option('systemcore_publisher_settings', []);
}

$pub_status        = $pub_options['status']          ?? 'publish';
$pub_per_batch     = (int) ($pub_options['posts_per_batch'] ?? 5);
$pub_default_lang  = $pub_options['default_lang']    ?? 'ar';
$pub_authors       = $pub_options['publishers']      ?? [];
$pub_ai_rewrite    = !empty($pub_options['enable_ai_rewrite']);
$pub_ai_category   = !empty($pub_options['enable_ai_category']);
$pub_fixed_cat     = (int) ($pub_options['category_id'] ?? ($pub_options['fixed_category_id'] ?? 0));

$pub_langs         = $pub_options['languages'] ?? [];
$pub_langs_total   = is_array($pub_langs) ? count($pub_langs) : 0;
$pub_langs_active  = 0;

if ($pub_langs_total > 0) {
    foreach ($pub_langs as $cfg) {
        if (!empty($cfg['active'])) {
            $pub_langs_active++;
        }
    }
}

/* ============================================================
 *  ADMIN TABS URLs
 * ============================================================ */
$base     = admin_url('admin.php?page=systemcore-dashboard');
$ai_url   = $base . '&tab=ai';
$pub_url  = $base . '&tab=publisher';
$queue_url= $base . '&tab=queue';
$logs_url = $base . '&tab=logs';
$feeds_url= $base . '&tab=feeds';

?>
<div class="sc-page">
    <h1 class="sc-title">SystemCore — System Overview</h1>

    <!-- TOP KPIs -->
    <div class="sc-grid sc-grid-4" style="margin-top:20px;">

        <div class="sc-card">
            <div class="sc-kpi-title">Feed Sources</div>
            <div class="sc-kpi-value"><?php echo (int) $feed_total; ?></div>
            <p style="margin:6px 0 0;font-size:12px;">
                RSS: <?php echo (int) $feed_rss; ?> &nbsp;•&nbsp;
                XML: <?php echo (int) $feed_xml; ?> &nbsp;•&nbsp;
                JSON: <?php echo (int) $feed_json; ?>
            </p>
            <p style="margin:6px 0 0;">
                <a href="<?php echo esc_url($feeds_url); ?>">Open Feed Sources</a>
            </p>
        </div>

        <div class="sc-card">
            <div class="sc-kpi-title">Queue (Pending / Total)</div>
            <div class="sc-kpi-value">
                <span class="sc-orange"><?php echo (int) $queue_pending; ?></span>
                <span style="font-size:16px;color:#888;"> / <?php echo (int) $queue_total; ?></span>
            </div>
            <p style="margin:6px 0 0;font-size:12px;">
                Processed (done): <span class="sc-green"><?php echo (int) $queue_done; ?></span>
            </p>
            <p style="margin:6px 0 0;">
                <a href="<?php echo esc_url($queue_url); ?>">Open Queue</a>
            </p>
        </div>

        <div class="sc-card">
            <div class="sc-kpi-title">Posts Published Today</div>
            <div class="sc-kpi-value sc-green"><?php echo (int) $today_published; ?></div>
            <p style="margin:6px 0 0;font-size:12px;">
                Total published via SystemCore: <?php echo (int) $all_published; ?>
            </p>
        </div>

        <div class="sc-card">
            <div class="sc-kpi-title">Log Entries</div>
            <div class="sc-kpi-value"><?php echo (int) $logs_total; ?></div>
            <p style="margin:6px 0 0;font-size:12px;">
                Info: <?php echo (int) $logs_info; ?> &nbsp;•&nbsp;
                Warning: <?php echo (int) $logs_warning; ?> &nbsp;•&nbsp;
                Error: <?php echo (int) $logs_error; ?>
            </p>
            <p style="margin:6px 0 0;">
                <a href="<?php echo esc_url($logs_url); ?>">Open Logs</a>
            </p>
        </div>

    </div>

    <!-- AI + PUBLISHER OVERVIEW -->
    <div class="sc-grid sc-grid-2" style="margin-top:25px;">

        <div class="sc-card">
            <h2 class="sc-card-title">AI Engine Overview</h2>
            <table class="sc-table sc-table-compact sc-overview-table">
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">AI Engine Status</a></th>
                    <td><?php echo $ai_enabled ? 'Enabled' : 'Disabled'; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">API Connection</a></th>
                    <td><?php echo $ai_connected ? 'Connected (API key set)' : 'Not Connected'; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">Default Model</a></th>
                    <td><?php echo esc_html($ai_model); ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">Default Language</a></th>
                    <td><?php echo esc_html($ai_lang); ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">Writing Style</a></th>
                    <td><?php echo esc_html($ai_style); ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">Rewrite Strength</a></th>
                    <td><?php echo (int) $ai_rewrite; ?>%</td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">Target Word Count</a></th>
                    <td><?php echo (int) $ai_target_wc; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">Title Length</a></th>
                    <td><?php echo (int) $ai_title_len; ?> chars</td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">Meta Length</a></th>
                    <td><?php echo (int) $ai_meta_len; ?> chars</td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($ai_url); ?>">SEO Mode</a></th>
                    <td><?php echo esc_html($ai_seo_mode); ?></td>
                </tr>
            </table>
            <p style="margin-top:10px;font-size:12px;">
                <a href="<?php echo esc_url($ai_url); ?>">Open AI Settings</a>
            </p>
        </div>

        <div class="sc-card">
            <h2 class="sc-card-title">Publisher Overview</h2>
            <table class="sc-table sc-table-compact sc-overview-table">
                <tr>
                    <th><a href="<?php echo esc_url($pub_url); ?>">Post Status</a></th>
                    <td><?php echo esc_html($pub_status); ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($pub_url); ?>">Posts per Batch</a></th>
                    <td><?php echo (int) $pub_per_batch; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($pub_url); ?>">Default Language</a></th>
                    <td><?php echo esc_html($pub_default_lang); ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($pub_url); ?>">Authors</a></th>
                    <td>
                        <?php
                        echo !empty($pub_authors)
                            ? esc_html(implode(', ', array_map('intval', (array) $pub_authors)))
                            : '—';
                        ?>
                    </td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($pub_url); ?>">AI Rewrite</a></th>
                    <td><?php echo $pub_ai_rewrite ? 'Enabled' : 'Disabled'; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($pub_url); ?>">AI Category</a></th>
                    <td><?php echo $pub_ai_category ? 'Enabled' : 'Disabled'; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($pub_url); ?>">Fixed Category</a></th>
                    <td><?php echo (int) $pub_fixed_cat; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($pub_url); ?>">Languages</a></th>
                    <td>
                        Active: <?php echo (int) $pub_langs_active; ?>
                        / Total: <?php echo (int) $pub_langs_total; ?>
                    </td>
                </tr>
            </table>
            <p style="margin-top:10px;font-size:12px;">
                <a href="<?php echo esc_url($pub_url); ?>">Open Publisher Settings</a>
            </p>
        </div>

    </div>

    <!-- LOGS + CRON -->
    <div class="sc-grid sc-grid-2" style="margin-top:25px;">

        <div class="sc-card">
            <h2 class="sc-card-title">Logs Overview</h2>
            <table class="sc-table sc-table-compact sc-overview-table">
                <tr>
                    <th><a href="<?php echo esc_url($logs_url); ?>">Total Logs</a></th>
                    <td><?php echo (int) $logs_total; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($logs_url); ?>">Info</a></th>
                    <td><?php echo (int) $logs_info; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($logs_url); ?>">Warnings</a></th>
                    <td><?php echo (int) $logs_warning; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($logs_url); ?>">Errors</a></th>
                    <td><?php echo (int) $logs_error; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($logs_url); ?>">Debug</a></th>
                    <td><?php echo (int) $logs_debug; ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($logs_url); ?>">Last Log Entry</a></th>
                    <td><?php echo esc_html($last_log_time); ?></td>
                </tr>
                <tr>
                    <th><a href="<?php echo esc_url($logs_url); ?>">Last Error</a></th>
                    <td><?php echo esc_html($last_error_time); ?></td>
                </tr>
            </table>
            <p style="margin-top:10px;font-size:12px;">
                <a href="<?php echo esc_url($logs_url); ?>">Open Full Logs Page</a>
            </p>
        </div>

        <div class="sc-card">
            <h2 class="sc-card-title">Scheduler & Cron</h2>
            <table class="sc-table sc-table-compact sc-overview-table">
                <tr>
                    <th>WP Cron Status</th>
                    <td><?php echo esc_html($cron_status); ?></td>
                </tr>
                <tr>
                    <th>DISABLE_WP_CRON</th>
                    <td><?php echo $cron_disabled ? 'true' : 'false'; ?></td>
                </tr>
                <tr>
                    <th>Next Run</th>
                    <td><?php echo esc_html($cron_next_human); ?></td>
                </tr>
                <tr>
                    <th>Last Cron Completed</th>
                    <td><?php echo esc_html($last_cron_run); ?></td>
                </tr>
                <tr>
                    <th>Interval</th>
                    <td>Every 5 minutes</td>
                </tr>
            </table>
        </div>

    </div>

    <!-- FEED SOURCES DETAIL -->
    <div class="sc-card" style="margin-top:25px;">
        <h2 class="sc-card-title">Feed Sources Summary</h2>
        <p style="margin-top:0;">
            This section shows a high-level summary of your configured feed sources.
            For full editing, open the <a href="<?php echo esc_url($feeds_url); ?>">Feed Sources page</a>.
        </p>

        <table class="sc-table sc-table-compact">
            <tr>
                <th><a href="<?php echo esc_url($feeds_url); ?>">Total Sources</a></th>
                <td><?php echo (int) $feed_total; ?></td>
            </tr>
            <tr>
                <th><a href="<?php echo esc_url($feeds_url); ?>">RSS Sources</a></th>
                <td><?php echo (int) $feed_rss; ?></td>
            </tr>
            <tr>
                <th><a href="<?php echo esc_url($feeds_url); ?>">XML Sources</a></th>
                <td><?php echo (int) $feed_xml; ?></td>
            </tr>
            <tr>
                <th><a href="<?php echo esc_url($feeds_url); ?>">JSON Sources</a></th>
                <td><?php echo (int) $feed_json; ?></td>
            </tr>
        </table>
    </div>

</div>
