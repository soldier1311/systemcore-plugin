<?php
if (!defined('ABSPATH')) exit;

/**
 * Admin Menu
 */
add_action('admin_menu', function () {

    add_menu_page(
        'SystemCore',
        'SystemCore',
        'manage_options',
        'systemcore-dashboard',
        'systemcore_render_main_page',
        'dashicons-hammer',
        3
    );
});

/**
 * Main tabbed page renderer
 */
function systemcore_render_main_page() {

    if (!current_user_can('manage_options')) {
        wp_die('Not allowed');
    }

    /**
     * Tabs list (Dashboard is REMOVED)
     */
    $tabs = [
        'overview'  => 'System Overview',
        'ai'        => 'AI Settings',
        'publisher' => 'Publisher',
        'queue'     => 'Queue',
        'feeds'     => 'Feed Sources',
        'logs'      => 'Logs',
        'scraper'   => 'Scraper Test',
    ];

    /**
     * Default tab = overview
     */
    $active_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'overview';

    if (!isset($tabs[$active_tab])) {
        $active_tab = 'overview';
    }

    $base_url = admin_url('admin.php?page=systemcore-dashboard');
    ?>

    <div class="wrap systemcore-settings">
        <h1>SystemCore Control Panel</h1>

        <h2 class="nav-tab-wrapper">
            <?php foreach ($tabs as $key => $label): ?>
                <?php
                $url   = $base_url . '&tab=' . $key;
                $class = 'nav-tab' . ($active_tab === $key ? ' nav-tab-active' : '');
                ?>
                <a href="<?php echo esc_url($url); ?>" class="<?php echo esc_attr($class); ?>">
                    <?php echo esc_html($label); ?>
                </a>
            <?php endforeach; ?>
        </h2>

        <div class="systemcore-tab-content" style="margin-top: 20px;">
            <?php
            switch ($active_tab) {

                case 'overview':
                    include __DIR__ . '/system-overview.php';
                    break;

                case 'ai':
                    include __DIR__ . '/ai-settings.php';
                    break;

                case 'publisher':
                    include __DIR__ . '/publisher-settings.php';
                    break;

                case 'queue':
                    include __DIR__ . '/queue.php';
                    break;

                case 'feeds':
                    include __DIR__ . '/feed-sources.php';
                    break;

                case 'logs':
                    include __DIR__ . '/fetch-log.php';
                    break;

                case 'scraper':
                    include __DIR__ . '/test-scraper.php';
                    break;

                default:
                    include __DIR__ . '/system-overview.php';
                    break;
            }
            ?>
        </div>
    </div>

    <?php
}

/**
 * Admin Assets Loader (CSS + JS)
 */
add_action('admin_enqueue_scripts', function($hook) {

    if (strpos($hook, 'systemcore') === false) {
        return;
    }

    wp_enqueue_style(
        'systemcore-admin',
        SYSTEMCORE_PLUGIN_URL . 'assets/systemcore-admin.css',
        [],
        time()
    );

    wp_enqueue_script(
        'systemcore-admin',
        SYSTEMCORE_PLUGIN_URL . 'assets/systemcore-admin.js',
        ['jquery'],
        time(),
        true
    );

    wp_localize_script(
        'systemcore-admin',
        'SystemCoreAdmin',
        [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('systemcore_admin_nonce'),
        ]
    );
});

/**
 * ============================================================
 *  AJAX — Test API Now (Final Fixed Version)
 * ============================================================
 */
add_action('wp_ajax_systemcore_test_api_now', function () {

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Not allowed']);
    }

    // التحقق من الـ nonce
    check_ajax_referer('systemcore_admin_nonce', 'nonce');

    // تحميل الإعدادات
    $settings = get_option('systemcore_ai_settings', []);
    $api_key  = $settings['api_key'] ?? '';
    $model    = $settings['model'] ?? 'gpt-4o-mini';

    if (empty($api_key)) {
        wp_send_json_error(['message' => 'Missing API Key']);
    }

    // تنفيذ الاختبار
    $response = wp_remote_post(
        "https://api.openai.com/v1/chat/completions",
        [
            'headers' => [
                'Authorization' => "Bearer $api_key",
                'Content-Type'  => 'application/json'
            ],
            'body' => json_encode([
                'model'    => $model,
                'messages' => [['role' => 'user', 'content' => 'Test message']],
                'max_tokens' => 5,
            ]),
            'timeout' => 10
        ]
    );

    if (is_wp_error($response)) {
        wp_send_json_error(['message' => $response->get_error_message()]);
    }

    $code = wp_remote_retrieve_response_code($response);

    if ($code >= 200 && $code < 300) {
        wp_send_json_success(['message' => 'Connected successfully']);
    }

    wp_send_json_error([
        'message' => "API Error (HTTP $code)"
    ]);
});

