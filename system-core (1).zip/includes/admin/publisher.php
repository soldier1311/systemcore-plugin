<?php
if (!defined('ABSPATH')) exit;

$options  = systemcore_get_publisher_settings();
$defaults = systemcore_get_publisher_defaults();

if (isset($_POST['systemcore_publisher_save']) && check_admin_referer('systemcore_publisher_settings')) {

    if (class_exists('SystemCore_Logger')) {
        SystemCore_Logger::info(
            'Publisher settings update started',
            'publisher',
            json_encode($_POST)
        );
    }

    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'publish';
    if (!in_array($status, ['publish', 'draft', 'pending'], true)) {
        $status = 'publish';
    }

    $options['status']          = $status;
    $options['posts_per_batch'] = max(1, (int) ($_POST['posts_per_batch'] ?? 5));
    $options['default_thumb_id']= (int) ($_POST['default_thumb_id'] ?? 0);

    $raw_publishers = isset($_POST['publishers']) ? sanitize_text_field($_POST['publishers']) : '';
    $ids = array_filter(array_map('intval', preg_split('/[,\s]+/', $raw_publishers)));
    $options['publishers'] = $ids;

    $options['default_lang']       = sanitize_text_field($_POST['default_lang'] ?? 'ar');
    $options['enable_ai_rewrite']  = !empty($_POST['enable_ai_rewrite']) ? 1 : 0;
    $options['enable_ai_category'] = !empty($_POST['enable_ai_category']) ? 1 : 0;

    foreach (['ar','fr','de'] as $lang) {

        $lang_key = 'lang_' . $lang;

        $options['languages'][$lang]['active'] =
            !empty($_POST[$lang_key . '_active']) ? 1 : 0;

        $options['languages'][$lang]['categories_api'] =
            !empty($_POST[$lang_key . '_categories_api'])
                ? esc_url_raw($_POST[$lang_key . '_categories_api'])
                : $defaults['languages'][$lang]['categories_api'];

        $options['languages'][$lang]['prompts']['rewrite'] =
            !empty($_POST[$lang_key . '_prompt_rewrite'])
                ? wp_kses_post($_POST[$lang_key . '_prompt_rewrite'])
                : '';

        $options['languages'][$lang]['prompts']['category'] =
            !empty($_POST[$lang_key . '_prompt_category'])
                ? wp_kses_post($_POST[$lang_key . '_prompt_category'])
                : '';
    }

    update_option('systemcore_publisher_settings', $options);

    if (class_exists('SystemCore_Logger')) {
        SystemCore_Logger::info(
            'Publisher settings saved successfully',
            'publisher',
            json_encode($options)
        );
    }

    echo '<div class="notice notice-success"><p>Publisher settings saved successfully.</p></div>';
}

?>
<div class="sc-page">

    <h1 class="sc-title">Publisher Settings</h1>

    <div class="sc-grid sc-grid-3 sc-mt-20">
        <div class="sc-card">
            <div class="sc-kpi-title">Post Status</div>
            <div class="sc-kpi-value"><?php echo esc_html(ucfirst($options['status'])); ?></div>
        </div>
        <div class="sc-card">
            <div class="sc-kpi-title">Posts per Batch</div>
            <div class="sc-kpi-value"><?php echo (int) $options['posts_per_batch']; ?></div>
        </div>
        <div class="sc-card">
            <div class="sc-kpi-title">Default Language</div>
            <div class="sc-kpi-value"><?php echo esc_html(strtoupper($options['default_lang'])); ?></div>
        </div>
    </div>

    <form method="post" class="sc-mt-20">
        <?php wp_nonce_field('systemcore_publisher_settings'); ?>

        <div class="sc-grid sc-grid-2 sc-mt-20">

            <div class="sc-card">
                <h2 class="sc-card-title">General Settings</h2>
                <table class="sc-table sc-table-compact">
                    <tr>
                        <th>Status</th>
                        <td>
                            <select name="status">
                                <option value="publish" <?php selected($options['status'], 'publish'); ?>>Publish</option>
                                <option value="draft"   <?php selected($options['status'], 'draft');   ?>>Draft</option>
                                <option value="pending" <?php selected($options['status'], 'pending'); ?>>Pending</option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th>Posts per Batch</th>
                        <td>
                            <input type="number" name="posts_per_batch" min="1"
                                   value="<?php echo esc_attr($options['posts_per_batch']); ?>">
                        </td>
                    </tr>

                    <tr>
                        <th>Publishers (IDs)</th>
                        <td>
                            <input type="text" name="publishers"
                                   value="<?php echo esc_attr(implode(', ', $options['publishers'])); ?>">
                            <p class="description">Example: 2,4,5</p>
                        </td>
                    </tr>

                    <tr>
                        <th>Default Language</th>
                        <td>
                            <select name="default_lang">
                                <option value="ar" <?php selected($options['default_lang'], 'ar'); ?>>Arabic</option>
                                <option value="fr" <?php selected($options['default_lang'], 'fr'); ?>>French</option>
                                <option value="de" <?php selected($options['default_lang'], 'de'); ?>>German</option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th>Default Thumbnail ID</th>
                        <td>
                            <input type="number" name="default_thumb_id"
                                   value="<?php echo esc_attr($options['default_thumb_id']); ?>">
                        </td>
                    </tr>
                </table>
            </div>

            <div class="sc-card">
                <h2 class="sc-card-title">AI Settings</h2>
                <table class="sc-table sc-table-compact">
                    <tr>
                        <th>AI Rewrite</th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_ai_rewrite" value="1"
                                    <?php checked($options['enable_ai_rewrite'], 1); ?>>
                                Enable automatic rewriting
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>AI Category Detection</th>
                        <td>
                            <label>
                                <input type="checkbox" name="enable_ai_category" value="1"
                                    <?php checked($options['enable_ai_category'], 1); ?>>
                                Let AI choose category
                            </label>
                        </td>
                    </tr>
                </table>
            </div>

        </div>

        <div class="sc-section sc-mt-20">
            <h2 class="sc-card-title">Language Configuration</h2>

            <div class="sc-grid sc-grid-3 sc-mt-15">
                <?php
                $langs = ['ar' => 'Arabic', 'fr' => 'French', 'de' => 'German'];

                foreach ($langs as $code => $label):
                    $cfg = $options['languages'][$code];
                    $key = 'lang_' . $code;
                ?>
                    <div class="sc-card">
                        <h3 class="sc-card-title"><?php echo esc_html($label . " ({$code})"); ?></h3>

                        <table class="sc-table sc-table-compact">
                            <tr>
                                <th>Active</th>
                                <td>
                                    <label>
                                        <input type="checkbox"
                                               name="<?php echo esc_attr($key); ?>_active"
                                               value="1" <?php checked($cfg['active'], 1); ?>>
                                        Enable this language
                                    </label>
                                </td>
                            </tr>

                            <tr>
                                <th>Categories API URL</th>
                                <td>
                                    <input type="text"
                                           name="<?php echo esc_attr($key); ?>_categories_api"
                                           value="<?php echo esc_attr($cfg['categories_api']); ?>">
                                </td>
                            </tr>

                            <tr>
                                <th>Rewrite Prompt</th>
                                <td>
                                    <textarea name="<?php echo esc_attr($key); ?>_prompt_rewrite"><?php
                                        echo esc_textarea($cfg['prompts']['rewrite']); ?></textarea>
                                </td>
                            </tr>

                            <tr>
                                <th>Category Prompt</th>
                                <td>
                                    <textarea name="<?php echo esc_attr($key); ?>_prompt_category"><?php
                                        echo esc_textarea($cfg['prompts']['category']); ?></textarea>
                                </td>
                            </tr>
                        </table>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <p class="sc-mt-20">
            <button type="submit" name="systemcore_publisher_save" class="button button-primary">
                Save Settings
            </button>
        </p>

    </form>

</div>
