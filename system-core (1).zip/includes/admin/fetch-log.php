<?php
if (!defined('ABSPATH')) exit;
?>

<div class="sc-page">

    <h1 class="sc-title">System Logs (Last 3 Days)</h1>

    <div class="sc-card sc-mt-20">
        <h2 class="sc-card-title">Log Entries</h2>

        <table class="systemcore-table" id="sc-logs-table">
            <thead>
                <tr>
                    <th style="width:60px;">ID</th>
                    <th style="width:90px;">Level</th>
                    <th style="width:120px;">Context</th>
                    <th>Message</th>
                    <th style="width:160px;">Created At</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="5">Loading...</td></tr>
            </tbody>
        </table>

        <div style="margin-top:15px; display:flex; justify-content:flex-end;">
            <button type="button" class="button button-secondary" id="sc-logs-clear">
                Clear All Logs
            </button>
        </div>
    </div>

</div>
