<?php
if (!defined('ABSPATH')) exit;
?>

<div class="wrap systemcore-wrap">
    <h1>SystemCore – System Logs (Last 3 Days)</h1>

    <p class="description">
        This view displays system-level logs from Fetch, Scraper, AI, Publisher, Scheduler and Feed Loader for the last 3 days.
    </p>

    <div class="systemcore-card" style="margin-top:20px;">

        <div class="systemcore-card-header" style="display:flex;justify-content:space-between;align-items:center;">
            <strong>System Logs</strong>

            <button type="button" class="button button-secondary" id="sc-logs-clear">
                Clear All Logs
            </button>
        </div>

        <div class="systemcore-card-body">

            <table class="widefat fixed striped" id="sc-logs-table">
                <thead>
                    <tr>
                        <th width="6%">ID</th>
                        <th width="10%">Level</th>
                        <th width="12%">Context</th>
                        <th>Message</th>
                        <th width="18%">Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td colspan="5">Loading...</td></tr>
                </tbody>
            </table>

        </div>
    </div>
</div>
