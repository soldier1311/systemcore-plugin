<?php if (!defined('ABSPATH')) exit; ?>

<div class="sc-page">

    <h1 class="sc-title">Feed Sources</h1>

    <div class="sc-card">
        <h2 class="sc-card-title">About Feed Sources</h2>

        <p>
            These are the active feed sources currently hard-coded inside
            <code>SystemCore_Feed_Loader</code>.
        </p>

        <p>
            In future updates, we will move feed sources into database options
            so you can add / edit / remove them directly from this screen.
        </p>
    </div>

    <!-- LIST OF SOURCES -->
    <div class="sc-card sc-mt-30">
        <h2 class="sc-card-title">Active Sources</h2>

        <div class="sc-grid sc-grid-3">

            <div class="sc-card">
                <div class="sc-kpi-title">9to5google</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">Android Authority</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">Android Headlines</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">Android Police</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">GSMArena</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">FoneArena</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">GizmoChina</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">SamMobile</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">PhoneArena</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">SmartPrix</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">TechCrunch</div>
            </div>

            <div class="sc-card">
                <div class="sc-kpi-title">TechRadar</div>
            </div>

        </div>
    </div>

</div>
