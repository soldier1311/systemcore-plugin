<?php

if (!defined('ABSPATH')) exit;

class SystemCore_Feed_Loader {

    /**
     * Load all feeds (RSS / XML / JSON) and push items into the queue.
     */
    public static function load_feeds($lang = 'ar') {

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'SystemCore_Feed_Loader::load_feeds() started',
                'feed',
                json_encode(['lang' => $lang])
            );
        }

        global $wpdb;

        $queue_table = $wpdb->prefix . 'systemcore_queue';
        $feeds_table = $wpdb->prefix . 'systemcore_feed_sources';

        /*
        ------------------------------------------------------------
        Cleanup queue items older than 4 hours (was 6h)
        ------------------------------------------------------------
        */
        $deleted = $wpdb->query(
            "DELETE FROM {$queue_table} WHERE created_at < (NOW() - INTERVAL 4 HOUR)"
        );

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Old queue cleanup completed (4h rule)',
                'feed',
                json_encode(['deleted_rows' => (int) $deleted])
            );
        }

        /*
        ------------------------------------------------------------
        Fetch all feed sources
        ------------------------------------------------------------
        */
        $feeds = $wpdb->get_results("SELECT * FROM {$feeds_table}");

        if (empty($feeds)) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::warning('No feed sources found in DB', 'feed');
            }
            return;
        }

        /*
        ------------------------------------------------------------
        Process each feed depending on its type
        ------------------------------------------------------------
        */
        foreach ($feeds as $feed) {

            $feed_id   = isset($feed->id) ? (int) $feed->id : 0;
            $feed_name = isset($feed->source_name) ? trim($feed->source_name) : ('Feed #' . $feed_id);
            $feed_url  = isset($feed->feed_url) ? esc_url_raw($feed->feed_url) : '';

            if (empty($feed_url)) {
                if (class_exists('SystemCore_Logger')) {
                    SystemCore_Logger::warning(
                        'Skipped feed: empty URL',
                        'feed',
                        json_encode(['feed_id' => $feed_id])
                    );
                }
                continue;
            }

            /*
            ------------------------------------------------------------
            Feed type selection (RSS / XML / JSON)
            ------------------------------------------------------------
            */
            $feed_type = !empty($feed->feed_type)
                ? strtolower(trim($feed->feed_type))
                : 'rss';

            /*
            ------------------------------------------------------------
            Placeholder for future: source priority / twitter mode
            ------------------------------------------------------------
            */
            $priority = isset($feed->priority) ? (int)$feed->priority : 10;
            $is_twitter = (!empty($feed->twitter_mode) && $feed->twitter_mode === 'yes');

            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::info(
                    'Processing feed',
                    'feed',
                    json_encode([
                        'id'       => $feed_id,
                        'name'     => $feed_name,
                        'type'     => $feed_type,
                        'url'      => $feed_url,
                        'priority' => $priority,
                        'twitter'  => $is_twitter
                    ])
                );
            }

            switch ($feed_type) {

                case 'xml':
                    self::process_xml_feed($feed, $lang, $queue_table);
                    break;

                case 'json':
                    self::process_json_feed($feed, $lang, $queue_table);
                    break;

                case 'rss':
                default:
                    self::process_rss_feed($feed, $lang, $queue_table);
                    break;
            }
        }

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info('SystemCore_Feed_Loader::load_feeds() finished', 'feed');
        }
    }


    /* ======================================================================
     *  RSS FEED LOADER
     * ==================================================================== */

    protected static function process_rss_feed($feed, $lang, $queue_table) {

        if (!function_exists('fetch_feed')) {
            require_once ABSPATH . WPINC . '/feed.php';
        }

        $feed_id   = (int)$feed->id;
        $feed_name = trim($feed->source_name);
        $feed_url  = esc_url_raw($feed->feed_url);

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Fetching RSS feed',
                'feed',
                json_encode([
                    'feed_id' => $feed_id,
                    'name'    => $feed_name,
                    'url'     => $feed_url,
                ])
            );
        }

        $rss = fetch_feed($feed_url);

        if (is_wp_error($rss)) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::error(
                    'RSS fetch error',
                    'feed',
                    json_encode([
                        'feed_id' => $feed_id,
                        'url'     => $feed_url,
                        'error'   => $rss->get_error_message(),
                    ])
                );
            }
            return;
        }

        $maxitems = $rss->get_item_quantity(20);

        if ($maxitems <= 0) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::warning(
                    'RSS feed returned 0 items',
                    'feed',
                    json_encode(['feed_id' => $feed_id])
                );
            }
            return;
        }

        $items = $rss->get_items(0, $maxitems);

        foreach ($items as $item) {

            $title = trim(wp_strip_all_tags($item->get_title()));
            $link  = esc_url_raw($item->get_permalink());

            if (empty($link)) {
                continue;
            }

            /*
            ------------------------------------------------------------
            Publication date filter (4 hours strict)
            ------------------------------------------------------------
            */
            $pub = $item->get_date('Y-m-d H:i:s');
            if (empty($pub)) {
                $pub = current_time('mysql');
            }

            $published_time = strtotime($pub);

            if ($published_time !== false && $published_time < strtotime('-4 hours')) {
                continue;
            }

            /*
            ------------------------------------------------------------
            entry_id (fallback to URL)
            ------------------------------------------------------------
            */
            $entry_id = method_exists($item, 'get_id') ? $item->get_id() : '';
            if (empty($entry_id)) {
                $entry_id = $link;
            }

            /*
            ------------------------------------------------------------
            push item to queue with dedupe
            ------------------------------------------------------------
            */
            self::push_to_queue(
                $feed_id,
                $feed_name,
                $link,
                $title,
                $lang,
                $queue_table,
                $entry_id
            );
        }
    }
    /* ======================================================================
     *  XML FEED LOADER (CUSTOM XML)
     * ==================================================================== */

    protected static function process_xml_feed($feed, $lang, $queue_table) {

        $feed_id   = (int)$feed->id;
        $feed_name = trim($feed->source_name);
        $feed_url  = esc_url_raw($feed->feed_url);

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Fetching XML feed',
                'feed',
                json_encode([
                    'feed_id' => $feed_id,
                    'name'    => $feed_name,
                    'url'     => $feed_url,
                ])
            );
        }

        $body = self::fetch_remote_body($feed_url);
        if ($body === false) {
            return;
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($body);
        if (!$xml) {
            return;
        }

        $root_path  = !empty($feed->xml_root_path) ? trim($feed->xml_root_path) : 'item';
        $xpath_path = '//' . trim($root_path, '/');

        $nodes = $xml->xpath($xpath_path);
        if (!$nodes || !is_array($nodes)) {
            return;
        }

        $mapping = [];
        if (!empty($feed->xml_mapping)) {
            $decoded = json_decode($feed->xml_mapping, true);
            if (is_array($decoded)) {
                $mapping = $decoded;
            }
        }

        $mapping = array_merge([
            'entry_id' => 'id',
            'title'    => 'title',
            'content'  => 'description',
            'link'     => 'link',
            'date'     => 'pubDate',
        ], $mapping);

        foreach ($nodes as $node) {

            $entry_id = isset($node->{$mapping['entry_id']}) ? (string)$node->{$mapping['entry_id']} : '';
            $title    = isset($node->{$mapping['title']})    ? (string)$node->{$mapping['title']}    : '';
            $content  = isset($node->{$mapping['content']})  ? (string)$node->{$mapping['content']}  : '';
            $link     = isset($node->{$mapping['link']})     ? (string)$node->{$mapping['link']}     : '';
            $date     = isset($node->{$mapping['date']})     ? (string)$node->{$mapping['date']}     : '';

            $title = trim(wp_strip_all_tags($title));
            $link  = esc_url_raw($link);

            if (empty($link)) {
                continue;
            }

            if (empty($entry_id)) {
                $entry_id = $link;
            }

            /*
            ------------------------------------------------------------
            Publication date filter (4 hours strict)
            ------------------------------------------------------------
            */
            if (!empty($date)) {
                $published_time = strtotime($date);
                if ($published_time !== false && $published_time < strtotime('-4 hours')) {
                    continue;
                }
            }

            /*
            ------------------------------------------------------------
            Push to queue (dedupe included)
            ------------------------------------------------------------
            */
            self::push_to_queue(
                $feed_id,
                $feed_name,
                $link,
                $title,
                $lang,
                $queue_table,
                $entry_id
            );
        }
    }

    /* ======================================================================
     *  JSON FEED LOADER
     * ==================================================================== */

    protected static function process_json_feed($feed, $lang, $queue_table) {

        $feed_id   = (int)$feed->id;
        $feed_name = trim($feed->source_name);
        $feed_url  = esc_url_raw($feed->feed_url);

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Fetching JSON feed',
                'feed',
                json_encode([
                    'feed_id' => $feed_id,
                    'name'    => $feed_name,
                    'url'     => $feed_url
                ])
            );
        }

        $body = self::fetch_remote_body($feed_url);
        if ($body === false) {
            return;
        }

        $data = json_decode($body, true);
        if (!is_array($data)) {
            return;
        }

        $root_path = !empty($feed->json_root_path) ? trim($feed->json_root_path) : '';
        $items     = self::extract_json_items($data, $root_path);

        if (empty($items) || !is_array($items)) {
            return;
        }

        $mapping = [];
        if (!empty($feed->json_mapping)) {
            $decoded = json_decode($feed->json_mapping, true);
            if (is_array($decoded)) {
                $mapping = $decoded;
            }
        }

        $mapping = array_merge([
            'entry_id' => 'id',
            'title'    => 'title',
            'content'  => 'content',
            'link'     => 'url',
            'date'     => 'publishedAt'
        ], $mapping);

        foreach ($items as $item) {

            if (!is_array($item)) continue;

            $entry_id = self::get_json_value($item, $mapping['entry_id']);
            $title    = self::get_json_value($item, $mapping['title']);
            $content  = self::get_json_value($item, $mapping['content']);
            $link     = self::get_json_value($item, $mapping['link']);
            $date     = self::get_json_value($item, $mapping['date']);

            $title = trim(wp_strip_all_tags((string)$title));
            $link  = esc_url_raw((string)$link);

            if (empty($link)) {
                continue;
            }

            if (empty($entry_id)) {
                $entry_id = $link;
            }

            /*
            ------------------------------------------------------------
            Publication date filter (4 hours strict)
            ------------------------------------------------------------
            */
            if (!empty($date)) {
                $published_time = strtotime($date);
                if ($published_time !== false && $published_time < strtotime('-4 hours')) {
                    continue;
                }
            }

            /*
            ------------------------------------------------------------
            Push to queue (with dedupe)
            ------------------------------------------------------------
            */
            self::push_to_queue(
                $feed_id,
                $feed_name,
                $link,
                $title,
                $lang,
                $queue_table,
                $entry_id
            );
        }
    }
    /* ======================================================================
     *  push_to_queue — Now includes Strong Dedupe (URL + Title Hash)
     * ==================================================================== */

    protected static function push_to_queue($feed_id, $feed_name, $link, $title, $lang, $queue_table, $entry_id = '') {
        global $wpdb;

        /*
        ------------------------------------------------------------
        DEDUPE CHECK #1 — URL already used in queue
        ------------------------------------------------------------
        */
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$queue_table} WHERE url = %s LIMIT 1",
                $link
            )
        );

        if ($exists) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::info("Skipped duplicate URL in queue: {$link}", 'feed');
            }
            return;
        }

        /*
        ------------------------------------------------------------
        DEDUPE CHECK #2 — URL or title_hash exists in systemcore_dedupe table
        ------------------------------------------------------------
        */
        if (class_exists('SystemCore_Dedupe')) {

            $normalized_title = mb_strtolower(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($title))));
            $title_hash = md5($normalized_title);

            $dup = $wpdb->get_var(
                $wpdb->prepare(
                    "
                    SELECT id FROM {$wpdb->prefix}systemcore_dedupe
                    WHERE url = %s OR title_hash = %s
                    LIMIT 1
                    ",
                    $link,
                    $title_hash
                )
            );

            if (!empty($dup)) {
                if (class_exists('SystemCore_Logger')) {
                    SystemCore_Logger::info("Skipped duplicate by DEDUPE table: {$link}", 'feed');
                }
                return;
            }

            /*
            ------------------------------------------------------------
            Register dedupe entry (no content_hash yet, feed-only stage)
            ------------------------------------------------------------
            */
            SystemCore_Dedupe::add(
                $link,
                $title,
                '',       // no content hash yet (will be added after scrape)
                '',       // no image hash yet
                (int)$feed_id,
                'feed'
            );
        }

        /*
        ------------------------------------------------------------
        QUEUE INSERT (via Queue Manager)
        ------------------------------------------------------------
        */
        $added = false;

        if (class_exists('SystemCore_Queue') && method_exists('SystemCore_Queue', 'add')) {
            $added = SystemCore_Queue::add($feed_id, $link, $lang);
        } else {
            $added = $wpdb->insert(
                $queue_table,
                [
                    'feed_id'    => $feed_id,
                    'url'        => $link,
                    'lang'       => $lang,
                    'status'     => 'pending',
                    'attempts'   => 0,
                    'created_at' => current_time('mysql'),
                ]
            );
        }

        if ($added) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::info(
                    'Queued article',
                    'feed',
                    json_encode([
                        'feed_id'   => $feed_id,
                        'feed_name' => $feed_name,
                        'url'       => $link,
                        'lang'      => $lang,
                        'title'     => $title,
                        'entry_id'  => $entry_id,
                    ])
                );
            }
        } else {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::error(
                    'Failed to queue article',
                    'feed',
                    json_encode([
                        'feed_id'   => $feed_id,
                        'feed_name' => $feed_name,
                        'url'       => $link,
                        'lang'      => $lang,
                        'title'     => $title,
                        'entry_id'  => $entry_id,
                    ])
                );
            }
        }
    }

    /* ======================================================================
     *  Helpers (HTTP + JSON)
     * ==================================================================== */

    protected static function fetch_remote_body($url) {

        $response = wp_remote_get($url, [
            'timeout'     => 15,
            'redirection' => 5,
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        return (!is_string($body) || $body === '') ? false : $body;
    }

    protected static function extract_json_items(array $data, $root_path = '') {

        if (empty($root_path)) {
            return $data;
        }

        $parts   = explode('.', $root_path);
        $current = $data;

        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '') continue;
            if (!isset($current[$part])) return [];
            $current = $current[$part];
        }

        return $current;
    }

    protected static function get_json_value(array $item, $path) {

        if ($path === '' || $path === null) {
            return '';
        }

        if (strpos($path, '.') === false) {
            return isset($item[$path]) ? $item[$path] : '';
        }

        $parts   = explode('.', $path);
        $current = $item;

        foreach ($parts as $part) {
            $part = trim($part);
            if ($part === '') continue;

            if (!is_array($current) || !array_key_exists($part, $current)) {
                return '';
            }

            $current = $current[$part];
        }

        return $current;
    }
}
