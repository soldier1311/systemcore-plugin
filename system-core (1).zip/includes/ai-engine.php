<?php
// includes/ai-engine.php

if (!defined('ABSPATH')) exit;

class SystemCore_AI_Engine {

    /* ============================================
       SETTINGS
    ============================================ */

    private static function get_settings() {
        $defaults = [
            'enabled'           => 'yes',
            'api_key'           => '',
            'model'             => 'gpt-4.1-mini',
            'rewrite_strength'  => 70,
            'default_language'  => 'auto',
            'writing_style'     => 'tech_journalism',
            'add_intro'         => 'yes',
            'add_conclusion'    => 'yes',
            'use_h2_h3'         => 'yes',
            'target_word_count' => 600,
            'meta_length'       => 160,
            'title_length'      => 60,
            'seo_mode'          => 'advanced',
            'model_rewrite'     => 'default',
            'model_title'       => 'default',
            'model_seo'         => 'default',
            'model_keywords'    => 'default',
            'model_language'    => 'default',
            'api_endpoint'      => '',
        ];

        $settings = get_option('systemcore_ai_settings', []);
        return is_array($settings) ? array_merge($defaults, $settings) : $defaults;
    }

    private static function get_api_key() {
        $s = self::get_settings();
        $key = trim((string) ($s['api_key'] ?? ''));
        return $key ?: null;
    }

    private static function get_model($task) {
        $s  = self::get_settings();
        $tk = "model_{$task}";
        if (!empty($s[$tk]) && $s[$tk] !== 'default') {
            return $s[$tk];
        }
        return $s['model'] ?? 'gpt-4.1-mini';
    }

    /* ============================================
       CORE ASK
    ============================================ */

    public static function ask($prompt, $task = 'generic') {
        $prompt = trim((string) $prompt);
        if ($prompt === '') return '';
        $model = self::get_model($task);
        $response = self::call_openai($prompt, $model);
        return is_string($response) ? trim($response) : '';
    }

    /* ============================================
       OPENAI CALL — Correct Responses API
    ============================================ */

    private static function call_openai($prompt, $model = null) {

        $api_key = self::get_api_key();
        if (!$api_key) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::error("AI Engine: Missing API Key", "ai");
            }
            return '';
        }

        $settings = self::get_settings();

        $endpoint = !empty($settings['api_endpoint'])
            ? trim($settings['api_endpoint'])
            : "https://api.openai.com/v1/responses";

        if (!$model || $model === 'default') {
            $model = $settings['model'] ?? 'gpt-4.1-mini';
        }

        // VALID Responses API format
        $body = [
            "model" => $model,
            "input" => $prompt,
            "max_output_tokens" => 1500
        ];

        $args = [
            "body"    => json_encode($body),
            "headers" => [
                "Content-Type"  => "application/json",
                "Authorization" => "Bearer " . $api_key
            ],
            "timeout" => 45
        ];

        $response = wp_remote_post($endpoint, $args);

        if (is_wp_error($response)) {
            SystemCore_Logger::error("AI HTTP error: " . $response->get_error_message(), "ai");
            return '';
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw  = wp_remote_retrieve_body($response);

        if ($code < 200 || $code >= 300) {
            SystemCore_Logger::error("AI HTTP status $code body: $raw", "ai");
            return '';
        }

        $json = json_decode($raw, true);

        // DIRECT Responses API text
        if (!empty($json["output_text"])) {
            return trim($json["output_text"]);
        }

        // STRUCTURED Responses API
        if (!empty($json["output"][0]["content"][0]["text"])) {
            return trim($json["output"][0]["content"][0]["text"]);
        }

        // Fallback Chat mode
        if (!empty($json["choices"][0]["message"]["content"])) {
            return trim($json["choices"][0]["message"]["content"]);
        }

        return '';
    }

    /* ============================================
       LANGUAGE HELPERS
    ============================================ */

    private static function normalize_lang($lang) {
        $lang = strtolower(trim((string) $lang));
        if ($lang === '') {
            $s = self::get_settings();
            $lang = strtolower(trim((string) ($s['default_language'] ?? 'auto')));
        }
        return $lang ?: 'auto';
    }

    private static function get_lang_label($lang) {
        $lang = self::normalize_lang($lang);
        return [
            'ar' => 'modern standard Arabic',
            'fr' => 'natural French',
            'de' => 'natural German',
            'en' => 'natural English',
            'auto' => 'the same language as the input text'
        ][$lang] ?? 'the same language as the input text';
    }

    /* ============================================
       TITLE REWRITE
    ============================================ */

    public static function rewrite_title($title, $lang = null) {
        $title = trim($title);
        if ($title === '') return '';

        $settings   = self::get_settings();
        $lang_label = self::get_lang_label($lang);
        $max_len    = (int) ($settings['title_length'] ?? 60);
        $style      = $settings['writing_style'] ?? 'tech_journalism';

        $prompt =
            "Rewrite the following technology news title in {$lang_label}:\n\n" .
            "Rules:\n" .
            "- Max {$max_len} characters\n" .
            "- High CTR but not clickbait\n" .
            "- Clear, neutral, professional ({$style})\n" .
            "- No emojis, no quotes\n\n" .
            "Original:\n{$title}\n\nReturn ONLY the rewritten title.";

        return trim(self::ask($prompt, 'title'));
    }

    /* ============================================
       CONTENT REWRITE
    ============================================ */

    public static function rewrite_content($content, $lang = 'ar') {
        $content = trim($content);
        if ($content === '') return '';

        $settings   = self::get_settings();
        $lang_label = self::get_lang_label($lang);

        $prompt =
            "Rewrite and enhance the following technology article in {$lang_label}:\n\n" .
            "Rules:\n" .
            "- Improve clarity and flow\n" .
            "- Keep technical accuracy\n" .
            "- Add light SEO structure\n" .
            "- Use HTML <p>, <h2>, <h3>, and lists\n" .
            "- No title generation\n\n" .
            "Article:\n{$content}\n\n" .
            "Return ONLY the article body.";

        return trim(self::ask($prompt, 'rewrite'));
    }

    /* ============================================
       META DESCRIPTION
    ============================================ */

    public static function generate_meta_description($content, $lang = null) {
        $content = trim($content);
        if ($content === '') return '';

        $settings   = self::get_settings();
        $lang_label = self::get_lang_label($lang);
        $max        = (int) ($settings['meta_length'] ?? 160);

        $prompt =
            "Write a {$lang_label} SEO meta description (max {$max} characters).\n" .
            "No emojis. No quotes.\n\n" .
            "Article:\n{$content}\n\nReturn description only.";

        $result = trim(self::ask($prompt, "seo"));

        return mb_substr($result, 0, $max);
    }

    /* ============================================
       KEYWORDS
    ============================================ */

    public static function generate_keywords($content, $lang = null) {
        $content = trim($content);
        if ($content === '') return '';

        $lang_label = self::get_lang_label($lang);

        $prompt =
            "Extract 5–10 short SEO keywords in {$lang_label}.\n" .
            "Return ONLY comma-separated list.\n\n" .
            "Text:\n{$content}";

        return trim(self::ask($prompt, "keywords"));
    }

    /* ============================================
       FULL ARTICLE
    ============================================ */

    public static function rewrite_full_article($title, $content, $lang = 'ar') {
        $lang = self::normalize_lang($lang);

        return [
            "lang"     => $lang,
            "title"    => self::rewrite_title($title, $lang),
            "content"  => self::rewrite_content($content, $lang),
            "meta"     => self::generate_meta_description($content, $lang),
            "keywords" => self::generate_keywords($content, $lang)
        ];
    }
}
