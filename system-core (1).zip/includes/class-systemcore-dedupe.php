<?php

if (!defined('ABSPATH')) exit;

class SystemCore_Dedupe {

    private static function table() {
        global $wpdb;
        return $wpdb->prefix . 'systemcore_dedupe';
    }

    public static function add($url, $title, $content_hash = '', $image_hash = '', $source_id = 0, $source_type = '') {
        global $wpdb;

        if (empty($url) && empty($title)) {
            return false;
        }

        $table = self::table();

        $clean_title = wp_strip_all_tags((string) $title);
        $normalized_title = mb_strtolower(trim(preg_replace('/\s+/', ' ', $clean_title)));
        $title_hash = $normalized_title !== '' ? md5($normalized_title) : '';

        $data = [
            'url'          => esc_url_raw((string) $url),
            'title'        => $clean_title,
            'title_hash'   => $title_hash,
            'content_hash' => substr((string) $content_hash, 0, 64),
            'image_hash'   => substr((string) $image_hash, 0, 64),
            'source_id'    => (int) $source_id,
            'source_type'  => sanitize_key($source_type),
            'created_at'   => current_time('mysql'),
        ];

        $formats = [
            '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s'
        ];

        return (bool) $wpdb->insert($table, $data, $formats);
    }

    public static function cleanup() {
        global $wpdb;

        $table = self::table();

        $sql = $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE created_at < DATE_SUB(%s, INTERVAL 7 DAY)",
            current_time('mysql')
        );

        $wpdb->query($sql);
    }

}
