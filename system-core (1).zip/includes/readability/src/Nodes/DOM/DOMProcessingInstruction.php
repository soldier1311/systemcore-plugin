<?php

namespace andreskrey\Readability\Nodes\DOM;

use andreskrey\Readability\Nodes\NodeTrait;

class DOMProcessingInstruction extends \DOMProcessingInstruction
{
    use NodeTrait;
}
