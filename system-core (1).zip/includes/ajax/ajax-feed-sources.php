<?php
if (!defined('ABSPATH')) exit;

require_once SYSTEMCORE_PLUGIN_PATH . 'includes/security.php';

global $wpdb;
$table = $wpdb->prefix . 'systemcore_feed_sources';

add_action('wp_ajax_systemcore_get_feed_source', function () use ($wpdb, $table) {
    SystemCore_Security::verify();

    $id = SystemCore_Security::clean($_POST['id'] ?? 0);
    if ($id < 1) {
        wp_send_json_error(['message' => 'Invalid ID']);
    }

    $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $id));

    if (!$row) {
        wp_send_json_error(['message' => 'Source not found']);
    }

    wp_send_json_success([
        'id'          => $row->id,
        'source_name' => $row->source_name,
        'feed_url'    => $row->feed_url,
    ]);
});

add_action('wp_ajax_systemcore_save_feed_source', function () use ($wpdb, $table) {
    SystemCore_Security::verify();

    $id   = SystemCore_Security::clean($_POST['id'] ?? 0);
    $name = SystemCore_Security::clean($_POST['source_name'] ?? '');
    $url  = SystemCore_Security::clean_url($_POST['feed_url'] ?? '');

    if (!$name || !$url) {
        wp_send_json_error(['message' => 'Missing fields']);
    }

    if ($id > 0) {
        $wpdb->update(
            $table,
            ['source_name' => $name, 'feed_url' => $url],
            ['id' => $id]
        );
        wp_send_json_success(['message' => 'Source updated']);
    }

    $wpdb->insert(
        $table,
        ['source_name' => $name, 'feed_url' => $url]
    );

    wp_send_json_success([
        'message' => 'Source added',
        'id'      => $wpdb->insert_id
    ]);
});

add_action('wp_ajax_systemcore_delete_feed_source', function () use ($wpdb, $table) {
    SystemCore_Security::verify();

    $id = SystemCore_Security::clean($_POST['id'] ?? 0);
    if ($id < 1) {
        wp_send_json_error(['message' => 'Invalid ID']);
    }

    $wpdb->delete($table, ['id' => $id]);

    wp_send_json_success(['message' => 'Source deleted']);
});
