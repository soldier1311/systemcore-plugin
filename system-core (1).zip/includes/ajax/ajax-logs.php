<?php
if (!defined('ABSPATH')) exit;

global $wpdb;

/**
 * Logs List (with filters + search + pagination + cleanup)
 */
add_action('wp_ajax_systemcore_logs_list', function () {
    SystemCore_Security::verify();

    global $wpdb;
    $table = $wpdb->prefix . 'systemcore_logs';

    // Auto-delete records older than 3 days
    $date_limit = date('Y-m-d H:i:s', strtotime('-3 days'));
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$table} WHERE created_at < %s",
            $date_limit
        )
    );

    $page     = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
    $per_page = 50;
    $offset   = ($page - 1) * $per_page;

    $level  = isset($_POST['level']) ? sanitize_text_field($_POST['level']) : '';
    $source = isset($_POST['source']) ? sanitize_text_field($_POST['source']) : '';
    $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';

    $where   = [];
    $params  = [];

    $where[]  = "created_at >= %s";
    $params[] = $date_limit;

    if (!empty($level)) {
        $where[]  = "level = %s";
        $params[] = $level;
    }

    if (!empty($source)) {
        $where[]  = "source = %s";
        $params[] = $source;
    }

    if (!empty($search)) {
        $where[]  = "(message LIKE %s OR context LIKE %s)";
        $params[] = '%' . $wpdb->esc_like($search) . '%';
        $params[] = '%' . $wpdb->esc_like($search) . '%';
    }

    $where_sql = "WHERE " . implode(" AND ", $where);

    $sql_total = $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} {$where_sql}",
        $params
    );
    $total_items = (int) $wpdb->get_var($sql_total);
    $total_pages = max(1, ceil($total_items / $per_page));

    $sql_items = $wpdb->prepare(
        "SELECT id, level, source, message, context, created_at
         FROM {$table}
         {$where_sql}
         ORDER BY id DESC
         LIMIT %d OFFSET %d",
        array_merge($params, [$per_page, $offset])
    );

    $rows = $wpdb->get_results($sql_items, ARRAY_A);

    wp_send_json_success([
        'items'       => $rows ?: [],
        'page'        => $page,
        'total_pages' => $total_pages,
        'total_items' => $total_items
    ]);
});


/**
 * Clear logs (delete all + keep table structure)
 */
add_action('wp_ajax_systemcore_logs_clear', function () {
    SystemCore_Security::verify();

    global $wpdb;
    $table = $wpdb->prefix . 'systemcore_logs';

    $wpdb->query("TRUNCATE TABLE {$table}");

    wp_send_json_success(['message' => 'Logs cleared.']);
});
