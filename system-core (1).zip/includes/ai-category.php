<?php
if (!defined('ABSPATH')) exit;

class SystemCore_AI_Category {

    /**
     * Main AI-based category selector
     */
    public static function select($title, $content, array $categories, $lang = 'ar') {

        if (empty($categories)) {
            return 0;
        }

        $list = '';
        foreach ($categories as $cat) {
            if (!empty($cat['id']) && !empty($cat['name'])) {
                $list .= $cat['id'] . ' - ' . $cat['name'] . "\n";
            }
        }

        $prompt = "
Choose the most suitable category ID for this article.
Return only the category ID with no extra text.

Categories:
{$list}

Title:
{$title}

Content:
{$content}
        ";

        $response = SystemCore_AI_Engine::ask($prompt, 'category');

        if (!is_string($response)) {
            return 0;
        }

        if (preg_match('/\d+/', $response, $m)) {
            return (int) $m[0];
        }

        return 0;
    }

    /**
     * Safe version with fallback
     */
    public static function select_safe($title, $content, array $categories, $lang = 'ar') {
        $id = self::select($title, $content, $categories, $lang);

        if (!$id && !empty($categories)) {
            return (int) $categories[0]['id'];
        }

        return $id;
    }
}
