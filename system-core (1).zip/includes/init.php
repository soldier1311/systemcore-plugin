<?php
if (!defined('ABSPATH')) exit;

/**
 * ============================================================
 *  Core System Modules (Load Order Is Important)
 * ============================================================
 */

// Database first
require_once __DIR__ . '/database.php';

// Dedupe system (global duplicate registry)
require_once __DIR__ . '/class-systemcore-dedupe.php';

// Logger second
require_once __DIR__ . '/logger.php';

// Scheduler
require_once __DIR__ . '/scheduler.php';

// Scraper (HTML extraction)
require_once __DIR__ . '/scraper.php';

// Feed Loader
require_once __DIR__ . '/class-systemcore-feed-loader.php';

// Queue System
require_once __DIR__ . '/queue.php';

/**
 * ============================================================
 *  AI Modules
 * ============================================================
 */

// Main AI Engine (rewrite, seo, titles)
require_once __DIR__ . '/ai-engine.php';

// AI Category Engine (NEW)
if (file_exists(__DIR__ . '/ai-category.php')) {
    require_once __DIR__ . '/ai-category.php';
}

/**
 * ============================================================
 *  Publisher (Multilingual version)
 * ============================================================
 */

// Publisher settings functions
require_once __DIR__ . '/publisher-functions.php';

// Publisher engine (NEW multilingual version)
require_once __DIR__ . '/publisher.php';

/**
 * ============================================================
 *  Admin Panel
 * ============================================================
 */

// Admin menu and pages
require_once __DIR__ . '/admin/index.php';

/**
 * ============================================================
 *  AJAX Handlers
 * ============================================================
 */

require_once __DIR__ . '/ajax/ajax-dashboard.php';
require_once __DIR__ . '/ajax/ajax-fetch.php';
require_once __DIR__ . '/ajax/ajax-queue.php';
require_once __DIR__ . '/ajax/ajax-logs.php';
require_once __DIR__ . '/ajax/ajax-publisher.php';
require_once __DIR__ . '/ajax/ajax-feed-sources.php';
