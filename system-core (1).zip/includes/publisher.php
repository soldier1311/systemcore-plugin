<?php
// includes/publisher.php

if (!defined('ABSPATH')) exit;

class SystemCore_Publisher {

    /**
     * Run one batch from the queue, publish Arabic first,
     * then create WPML translations (FR, DE).
     */
    public static function run_batch($primary_lang = 'ar') {
        global $wpdb;

        $settings = function_exists('systemcore_get_publisher_settings')
            ? systemcore_get_publisher_settings()
            : self::get_local_defaults();

        $status        = $settings['status']          ?? 'publish';
        $limit         = isset($settings['posts_per_batch']) ? max(1, (int)$settings['posts_per_batch']) : 5;
        $default_thumb = (int)($settings['default_thumb_id'] ?? 0);
        $authors       = (!empty($settings['publishers']) && is_array($settings['publishers']))
            ? $settings['publishers']
            : [1];

        $fixed_category_id   = (int)($settings['category_id'] ?? 0);
        $enable_ai_rewrite   = !empty($settings['enable_ai_rewrite']);
        $enable_ai_category  = !empty($settings['enable_ai_category']);
        $languages_settings  = is_array($settings['languages']) ? $settings['languages'] : [];

        // Log start
        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Publisher batch start',
                'publisher',
                wp_json_encode([
                    'limit'      => $limit,
                    'status'     => $status,
                    'fixed_cat'  => $fixed_category_id,
                ])
            );
        }

        // ===== AI ENGINE CHECK =====
        if (!class_exists('SystemCore_AI_Engine')) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::error('AI Engine class missing', 'publisher');
            }
            return ['success'=>false,'message'=>'AI Engine missing','published'=>[]];
        }

        $ai_settings = get_option('systemcore_ai_settings',[]);
        $ai_enabled  = ($ai_settings['enabled'] ?? '') === 'yes';
        $ai_key      = trim($ai_settings['api_key'] ?? '');

        if (!$ai_enabled || empty($ai_key) || !$enable_ai_rewrite) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::warning(
                    'AI disabled or key missing',
                    'publisher',
                    wp_json_encode([
                        'ai_enabled'       => $ai_enabled,
                        'has_key'          => !empty($ai_key),
                        'enable_ai_rewrite'=> $enable_ai_rewrite,
                    ])
                );
            }
            return ['success'=>false,'message'=>'AI disabled','published'=>[]];
        }

        // ===== WPML CHECK =====
        $wpml_ok = false;
        if (function_exists('icl_make_duplicate')) {
            $wpml_ok = true;
        } elseif (class_exists('SitePress')) {
            global $sitepress;
            if (is_object($sitepress) && method_exists($sitepress, 'make_duplicate')) {
                $wpml_ok = true;
            }
        }

        if (!$wpml_ok) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::warning('WPML duplicate API not available', 'publisher');
            }
            return ['success'=>false,'message'=>'WPML missing','published'=>[]];
        }

        // ===== LANG ORDER =====
        $order = ['ar','fr','de'];

        $active_langs = [];
        foreach ($order as $lng) {
            if (!empty($languages_settings[$lng]['active'])) {
                $active_langs[] = $lng;
            }
        }
        if (empty($active_langs)) {
            $active_langs = ['ar'];
        }

        // ===== QUEUE =====
        $table = $wpdb->prefix . 'systemcore_queue';

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE status=%s ORDER BY id ASC LIMIT %d",
                'pending',
                $limit
            )
        );

        if (empty($rows)) {
            if (class_exists('SystemCore_Logger')) {
                SystemCore_Logger::info('Publisher queue empty', 'publisher');
            }
            return ['success'=>true,'message'=>'Queue empty','published'=>[]];
        }

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Publisher fetched rows',
                'publisher',
                wp_json_encode(['count'=>count($rows)])
            );
        }

        $published   = [];
        $cat_cache   = [];

        foreach ($rows as $item) {

            $queue_id = (int)$item->id;
            $url      = trim($item->url);

            try {

                $scraped = SystemCore_Scraper::fetch_full_article($url);

                if (
                    empty($scraped['success']) ||
                    empty($scraped['title']) ||
                    empty($scraped['content']) ||
                    strlen(trim($scraped['content'])) < 200
                ) {
                    self::delete_queue($queue_id);
                    continue;
                }

                $raw_title   = trim($scraped['title']);
                $raw_content = trim($scraped['content']);
                $raw_image   = !empty($scraped['image']) ? trim($scraped['image']) : '';

                // download main image once (with deduplication)
                $thumb_id = 0;

                if (!empty($raw_image)) {
                    $thumb_id = self::download_image($raw_image, $raw_title);
                }

                if (!$thumb_id && $default_thumb > 0) {
                    $thumb_id = $default_thumb;
                }

                $lang_posts = [];

                // ===== ARABIC FIRST =====
                if (in_array('ar', $active_langs, true)) {

                    $article_ar = SystemCore_AI_Engine::rewrite_full_article(
                        $raw_title,
                        $raw_content,
                        'ar'
                    );

                    if (
                        empty($article_ar['title']) ||
                        empty($article_ar['content']) ||
                        strlen($article_ar['content']) < 200
                    ) {
                        self::delete_queue($queue_id);
                        continue;
                    }

                    $final_title_ar   = $article_ar['title'];
                    $final_content_ar = $article_ar['content'];
                    $final_excerpt_ar = $article_ar['meta'] ?? '';

                    // detect category
                    $category_id_ar = self::detect_category(
                        'ar',
                        $settings,
                        $enable_ai_category,
                        $fixed_category_id,
                        $cat_cache,
                        $final_title_ar,
                        $final_content_ar
                    );

                    // choose author
                    $author_ar = (int)$authors[array_rand($authors)];

                    // insert AR post (default language of site = Arabic)
                    $post_ar = wp_insert_post([
                        'post_title'   => $final_title_ar,
                        'post_content' => $final_content_ar,
                        'post_excerpt' => $final_excerpt_ar,
                        'post_status'  => $status,
                        'post_author'  => $author_ar,
                        'post_type'    => 'post',
                    ], true);

                    if (is_wp_error($post_ar) || !$post_ar) {
                        self::delete_queue($queue_id);
                        continue;
                    }

                    if ($category_id_ar > 0) {
                        wp_set_post_categories($post_ar, [$category_id_ar], false);
                    }

                    if ($thumb_id > 0) {
                        set_post_thumbnail($post_ar, $thumb_id);
                    }

                    update_post_meta($post_ar, '_systemcore_source_url', esc_url_raw($url));
                    update_post_meta($post_ar, '_systemcore_lang', 'ar');
                    update_post_meta($post_ar, '_systemcore_keywords', sanitize_text_field($article_ar['keywords'] ?? ''));

                    $lang_posts['ar'] = (int)$post_ar;
                    // dedupe: register AR post
                    if (class_exists('SystemCore_Dedupe')) {
                        $content_hash_ar = md5(substr(wp_strip_all_tags($final_content_ar), 0, 800));
                        $image_hash_ar   = $thumb_id ? get_post_meta($thumb_id, '_systemcore_image_hash', true) : '';
                        SystemCore_Dedupe::add(
                            $url,
                            $final_title_ar,
                            $content_hash_ar,
                            $image_hash_ar,
                            0,
                            'rss'
                        );
                    }


                    if (class_exists('SystemCore_Logger')) {
                        SystemCore_Logger::info(
                            'Publisher AR post created',
                            'publisher',
                            wp_json_encode(['post_id'=>$post_ar,'url'=>$url])
                        );
                    }
                }

                // إذا لم يوجد أساس عربي، لا نكمّل ترجمات
                if (empty($lang_posts['ar'])) {
                    self::delete_queue($queue_id);
                    continue;
                }

                // ===== TRANSLATIONS (FR, DE) =====
                foreach (['fr','de'] as $lng) {

                    if (!in_array($lng, $active_langs, true)) {
                        continue;
                    }

                    $article_lng = SystemCore_AI_Engine::rewrite_full_article(
                        $raw_title,
                        $raw_content,
                        $lng
                    );

                    if (
                        empty($article_lng['title']) ||
                        empty($article_lng['content']) ||
                        strlen($article_lng['content']) < 200
                    ) {
                        continue;
                    }

                    // detect category
                    $category_id_lng = self::detect_category(
                        $lng,
                        $settings,
                        $enable_ai_category,
                        $fixed_category_id,
                        $cat_cache,
                        $article_lng['title'],
                        $article_lng['content']
                    );

                    // create WPML duplicate from AR, then update
                    $translated_id = 0;

                    if (function_exists('icl_make_duplicate')) {
                        // old WPML API
                        $translated_id = icl_make_duplicate($lang_posts['ar'], $lng, $status);
                    } elseif (class_exists('SitePress')) {
                        global $sitepress;
                        if (is_object($sitepress) && method_exists($sitepress, 'make_duplicate')) {
                            $translated_id = $sitepress->make_duplicate($lang_posts['ar'], $lng);
                        }
                    }

                    if (!$translated_id) {
                        continue;
                    }

                    // update translated post with AI content
                    wp_update_post([
                        'ID'           => $translated_id,
                        'post_title'   => $article_lng['title'],
                        'post_content' => $article_lng['content'],
                        'post_excerpt' => $article_lng['meta'] ?? '',
                        'post_status'  => $status
                    ]);

                    if ($category_id_lng > 0) {
                        wp_set_post_categories($translated_id, [$category_id_lng], false);
                    }

                    if ($thumb_id > 0) {
                        set_post_thumbnail($translated_id, $thumb_id);
                    }

                    update_post_meta($translated_id, '_systemcore_lang', $lng);
                    update_post_meta($translated_id, '_systemcore_keywords', sanitize_text_field($article_lng['keywords'] ?? ''));

                    $lang_posts[$lng] = (int)$translated_id;
                    // dedupe: register translated post
                    if (class_exists('SystemCore_Dedupe')) {
                        $content_hash_lng = md5(substr(wp_strip_all_tags($article_lng['content']), 0, 800));
                        $image_hash_lng   = $thumb_id ? get_post_meta($thumb_id, '_systemcore_image_hash', true) : '';
                        SystemCore_Dedupe::add(
                            $url,
                            $article_lng['title'],
                            $content_hash_lng,
                            $image_hash_lng,
                            0,
                            'rss'
                        );
                    }


                    if (class_exists('SystemCore_Logger')) {
                        SystemCore_Logger::info(
                            'Publisher translation created',
                            'publisher',
                            wp_json_encode(['post_id'=>$translated_id,'lang'=>$lng])
                        );
                    }
                }

                self::delete_queue($queue_id);

                if (!empty($lang_posts)) {
                    $published[] = [
                        'queue_id' => $queue_id,
                        'posts'    => $lang_posts
                    ];
                }

            } catch (\Throwable $e) {

                if (class_exists('SystemCore_Logger')) {
                    SystemCore_Logger::error(
                        'Publisher exception: '.$e->getMessage(),
                        'publisher',
                        wp_json_encode(['queue_id'=>$queue_id])
                    );
                }

                self::delete_queue($queue_id);
                continue;
            }
        }

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Publisher batch finished',
                'publisher',
                wp_json_encode(['published'=>count($published)])
            );
        }

        return [
            'success'=>true,
            'message'=>'Batch finished',
            'published'=>$published
        ];
    }

    // ===== CATEGORY / HELPERS =====

    private static function detect_category($lang, $settings, $enable_ai, $fixed_cat, &$cache, $title, $content) {

        if (!empty($settings['languages'][$lang]['category_id'])) {
            return (int)$settings['languages'][$lang]['category_id'];
        }

        if ($fixed_cat > 0) {
            return $fixed_cat;
        }

        if (!$enable_ai) {
            return 0;
        }

        if (!isset($cache[$lang])) {
            $cache[$lang] = self::load_categories($lang, $settings);
        }

        $cats = $cache[$lang];
        if (empty($cats)) {
            return 0;
        }

        $selected = self::ai_select_category($title, $content, $cats);
        if ($selected > 0) {
            return $selected;
        }

        return (int)$cats[0]['id'];
    }

    private static function get_local_defaults() {
        return [
            'status'             => 'publish',
            'posts_per_batch'    => 5,
            'default_thumb_id'   => 0,
            'publishers'         => [1],
            'default_lang'       => 'ar',
            'category_id'        => 0,
            'enable_ai_rewrite'  => 1,
            'enable_ai_category' => 1,
            'languages'          => ['ar'=>['active'=>1]]
        ];
    }

    private static function delete_queue($id) {
        global $wpdb;
        $wpdb->delete($wpdb->prefix.'systemcore_queue', ['id'=>(int)$id], ['%d']);
    }

    private static function load_categories($lang, $settings) {

        $cache_key = 'systemcore_categories_'.$lang;
        $cached    = get_option($cache_key);

        if (!empty($cached)) {
            return $cached;
        }

        $lng_settings = $settings['languages'][$lang] ?? [];
        $api_url = $lng_settings['categories_api'] ?? '';

        if (!$api_url) {
            $api_url = add_query_arg([
                'per_page'=>100,
                'lang'=>$lang
            ], home_url('/wp-json/wp/v2/categories'));
        }

        $response = wp_remote_get($api_url, ['timeout'=>20]);
        if (is_wp_error($response)) {
            return [];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($body)) return [];

        $cats = [];
        foreach ($body as $c) {
            if (!empty($c['id'])) {
                $cats[] = [
                    'id'=>(int)$c['id'],
                    'name'=>(string)$c['name']
                ];
            }
        }

        update_option($cache_key, $cats);
        return $cats;
    }

    private static function ai_select_category($title, $content, array $categories) {

        if (empty($categories)) return 0;

        $list = '';
        foreach ($categories as $c) {
            $list .= "{$c['id']} - {$c['name']}\n";
        }

        $prompt =
            "Choose the best category ID.\n\n".
            "Categories:\n{$list}\n\n".
            "Title:\n{$title}\n\n".
            "Content:\n{$content}\n\n".
            "Return only the numeric ID.";

        $res = SystemCore_AI_Engine::ask($prompt, 'category');

        return preg_match('/\d+/', $res, $m) ? (int)$m[0] : 0;
    }

    /**
 * Download image with deduplication by HASH.
 * - يمنع تكرار الصور نهائياً حتى لو تغيّر رابط المصدر
 * - يخزّن hash في الميتا ويعيد استخدام نفس الصورة
 */
private static function download_image($url, $title = '') {

    if (empty($url)) {
        return 0;
    }

    // اجلب محتوى الصورة من المصدر
    $response = wp_remote_get($url, [
        'timeout' => 15,
        'redirection' => 5
    ]);

    if (is_wp_error($response)) {
        return 0;
    }

    $image_data = wp_remote_retrieve_body($response);
    if (empty($image_data)) {
        return 0;
    }

    // توليد hash فريد للصورة
    $hash = md5($image_data);

    global $wpdb;

    // هل يوجد مرفق سابق يحمل نفس الـ hash ؟
    $existing_id = (int) $wpdb->get_var(
        $wpdb->prepare(
            "
            SELECT p.ID
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} m ON p.ID = m.post_id
            WHERE p.post_type='attachment'
              AND m.meta_key = '_systemcore_image_hash'
              AND m.meta_value = %s
            LIMIT 1
            ",
            $hash
        )
    );

    // إعادة استخدام الصورة إذا كانت موجودة
    if ($existing_id > 0) {
        $path = get_attached_file($existing_id);
        if ($path && file_exists($path)) {
            return $existing_id;
        }
    }

    // اسم ملف مناسب
    $filename = sanitize_file_name($title);
    if (!$filename) {
        $filename = 'systemcore-image-' . wp_generate_password(6, false);
    }
    $filename .= '.jpg';

    // رفع الصورة فعلياً
    $upload = wp_upload_bits($filename, null, $image_data);

    if (!empty($upload['error']) || empty($upload['file'])) {
        return 0;
    }

    // إنشاء attachment
    $filetype = wp_check_filetype($upload['file'], null);

    $attachment = [
        'post_mime_type' => $filetype['type'],
        'post_title'     => $title,
        'post_content'   => '',
        'post_status'    => 'inherit'
    ];

    $attach_id = wp_insert_attachment($attachment, $upload['file']);

    if (is_wp_error($attach_id) || !$attach_id) {
        return 0;
    }

    // توليد metadata
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $metadata = wp_generate_attachment_metadata($attach_id, $upload['file']);
    wp_update_attachment_metadata($attach_id, $metadata);

    // تخزين الـ hash لمنع التكرار في المستقبل
    update_post_meta($attach_id, '_systemcore_image_hash', $hash);
    update_post_meta($attach_id, '_systemcore_image_source', esc_url_raw($url));

    return $attach_id;
}

}
