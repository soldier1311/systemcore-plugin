<?php

if (!defined('ABSPATH')) exit;

class SystemCore_Scheduler {

    /**
     * Initialize cron
     */
    public static function init() {

        // Custom interval: every 5 minutes
        add_filter('cron_schedules', function($schedules) {
            $schedules['every_5_minutes'] = [
                'interval' => 300,
                'display'  => 'Every 5 Minutes'
            ];
            return $schedules;
        });

        // Custom interval: every 12 hours for dedupe cleanup
        add_filter('cron_schedules', function($schedules) {
            $schedules['systemcore_12_hours'] = [
                'interval' => 12 * HOUR_IN_SECONDS,
                'display'  => 'Every 12 Hours (Dedupe Cleanup)'
            ];
            return $schedules;
        });

        self::register_cron();
    }

    /**
     * Register cron if not exists
     */
    public static function register_cron() {
        if (!wp_next_scheduled('systemcore_cron_runner')) {
            wp_schedule_event(time(), 'every_5_minutes', 'systemcore_cron_runner');
        }

        if (!wp_next_scheduled('systemcore_dedupe_cleanup_event')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'systemcore_12_hours', 'systemcore_dedupe_cleanup_event');
        }
    }
}

add_action('plugins_loaded', ['SystemCore_Scheduler', 'init']);


/**
 * Activation hook
 */
register_activation_hook(dirname(__FILE__, 2) . '/system-core.php', function () {

    // Every 5 minutes
    add_filter('cron_schedules', function($schedules) {
        $schedules['every_5_minutes'] = [
            'interval' => 300,
            'display'  => 'Every 5 Minutes'
        ];
        return $schedules;
    });

    // Every 12 hours
    add_filter('cron_schedules', function($schedules) {
        $schedules['systemcore_12_hours'] = [
            'interval' => 12 * HOUR_IN_SECONDS,
            'display'  => 'Every 12 Hours (Dedupe Cleanup)'
        ];
        return $schedules;
    });

    if (!wp_next_scheduled('systemcore_cron_runner')) {
        wp_schedule_event(time(), 'every_5_minutes', 'systemcore_cron_runner');
    }

    if (!wp_next_scheduled('systemcore_dedupe_cleanup_event')) {
        wp_schedule_event(time() + HOUR_IN_SECONDS, 'systemcore_12_hours', 'systemcore_dedupe_cleanup_event');
    }
});

/**
 * Deactivation hook
 */
register_deactivation_hook(dirname(__FILE__, 2) . '/system-core.php', function () {
    wp_clear_scheduled_hook('systemcore_cron_runner');
    wp_clear_scheduled_hook('systemcore_dedupe_cleanup_event');
});


/**
 * Main scheduled event
 */
add_action('systemcore_cron_runner', function () {

    SystemCore_Logger::info("CRON: systemcore_cron_runner started");

    // Feed Loader
    if (class_exists('SystemCore_Feed_Loader')) {
        SystemCore_Logger::info("CRON: Running Feed Loader (RSS/XML/JSON)");
        SystemCore_Feed_Loader::load_feeds('ar');
    }

    // AI Rewrite Engine (future)
    if (class_exists('SystemCore_AI_Rewriter')) {
        SystemCore_Logger::info("CRON: Running AI Rewrite Engine");
        SystemCore_AI_Rewriter::process_pending_items('ar');
    }

    // Publisher
    if (class_exists('SystemCore_Publisher')) {
        SystemCore_Logger::info("CRON: Running Publisher");
        SystemCore_Publisher::run_batch('ar');
    }

    // Logs cleanup (3 days)
    global $wpdb;
    $table = $wpdb->prefix . 'systemcore_logs';
    $date_limit = date('Y-m-d H:i:s', strtotime('-3 days'));

    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$table} WHERE created_at < %s",
            $date_limit
        )
    );

    SystemCore_Logger::info("CRON: Cleanup completed (logs older than 3 days removed)");
    SystemCore_Logger::info("CRON: systemcore_cron_runner completed");
});


/**
 * Dedupe Cleanup Event
 */
add_action('systemcore_dedupe_cleanup_event', function () {
    if (class_exists('SystemCore_Dedupe')) {
        SystemCore_Dedupe::cleanup();
    }
});
