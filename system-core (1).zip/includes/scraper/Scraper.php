<?php

if (!defined('ABSPATH')) exit;

class SystemCore_Scraper {

    private static function fail($msg = '', $url = '', $stage = '', $extra = []) {
        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::error(
                $msg ?: 'Scraper failure',
                'scraper',
                json_encode([
                    'url'   => $url,
                    'stage' => $stage,
                    'extra' => $extra,
                ])
            );
        }

        return [
            'success'     => false,
            'title'       => '',
            'content'     => '',
            'image'       => '',
            'description' => '',
            'canonical'   => '',
            'keywords'    => '',
            'links'       => [],
            'hashes'      => [],
            'error'       => $msg
        ];
    }

    public static function fetch_full_article($url) {

        $url = trim((string) $url);

        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return self::fail('Invalid URL', $url, 'validate');
        }

        // ---------------------------------------------------------
        // DEDUPE: Check URL
        // ---------------------------------------------------------
        if (class_exists('SystemCore_Dedupe')) {
            if (SystemCore_Dedupe::exists_url($url)) {
                return self::fail('Duplicate URL', $url, 'dedupe_url');
            }
        }

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Scraper started',
                'scraper',
                json_encode(['url' => $url])
            );
        }

        // ---------------------------------------------------------
        // HTTP Fetch
        // ---------------------------------------------------------
        $http = SystemCore_HttpClient::fetch($url);
        if (empty($http['ok'])) {
            return self::fail($http['error'] ?? 'HTTP fetch failed', $url, 'http');
        }

        $html = $http['html'] ?? '';
        if ($html === '') {
            return self::fail('Empty HTML', $url, 'html_empty');
        }

        // ---------------------------------------------------------
        // Mode detection (strict / readability / title-desc)
        // ---------------------------------------------------------
        $mode = get_option('systemcore_scraper_mode', 'readability');
        // allowed: strict | readability | simple

        // ---------------------------------------------------------
        // STRICT MODE → minimal extraction
        // ---------------------------------------------------------
        if ($mode === 'strict') {
            $strict = self::strict_extract($html, $url);
            if (!$strict['ok']) {
                return self::fail($strict['error'], $url, 'strict');
            }

            $title   = $strict['title'];
            $content = $strict['content'];
            $image   = $strict['image'];
            $desc    = $strict['description'];

            return self::finalize($url, $title, $content, $image, $desc, '');
        }

        // ---------------------------------------------------------
        // TITLE + DESCRIPTION MODE
        // ---------------------------------------------------------
        if ($mode === 'simple') {
            $simple = self::title_description_mode($html, $url);
            if (!$simple['ok']) {
                return self::fail($simple['error'], $url, 'titledesc');
            }

            $title   = $simple['title'];
            $desc    = $simple['description'];
            $img     = $simple['image'];
            $content = $title . "\n\n" . $desc;

            return self::finalize($url, $title, $content, $img, $desc, '');
        }

        // ---------------------------------------------------------
        // READABILITY MODE (default)
        // ---------------------------------------------------------
        $ext = SystemCore_ContentExtractor::extract($html, $url);
        if (empty($ext['ok'])) {
            return self::fail($ext['error'] ?? 'Extract failed', $url, 'extract');
        }

        $raw_html = $ext['raw_html'] ?? '';
        $title    = $ext['title']    ?? '';

        if ($raw_html === '') {
            return self::fail('Extractor returned empty HTML', $url, 'raw_empty');
        }

        $clean = SystemCore_ContentCleaner::clean($raw_html, $url, $title);
        if (empty($clean['ok'])) {
            return self::fail($clean['error'], $url, 'clean');
        }

        $clean_html = $clean['clean_html'] ?? '';
        $clean_text = $clean['clean_text'] ?? '';

        if ($clean_text === '') {
            return self::fail('Cleaned content empty', $url, 'clean_text_empty');
        }

        // ---------------------------------------------------------
        // Metadata
        // ---------------------------------------------------------
        $meta = SystemCore_MetadataParser::parse($html, $clean_html, $title, $url);

        $meta_title       = $meta['title']          ?? $title;
        $meta_description = $meta['description']    ?? '';
        $meta_keywords    = $meta['keywords']       ?? '';
        $meta_canonical   = $meta['canonical']      ?? '';
        $meta_links       = $meta['links']          ?? [];
        $meta_image       = $meta['image']          ?? '';

        // ---------------------------------------------------------
        // Image priority resolution
        // ---------------------------------------------------------
        $image = self::resolve_image($html, $clean_html, $meta_image, $url);

        // ---------------------------------------------------------
        // Quality Gate
        // ---------------------------------------------------------
        $q = SystemCore_QualityGate::validate($clean_text, $meta, $url);
        if (!empty($q['reject'])) {
            return self::fail($q['reason'], $url, 'quality');
        }

        return self::finalize(
            $url,
            $meta_title,
            $clean_text,
            $image,
            $meta_description,
            $meta_keywords,
            $meta_canonical,
            $meta_links
        );
    }

    // ------------------------------------------------------------
    // STRICT MODE BASIC PARSER
    // ------------------------------------------------------------
    private static function strict_extract($html, $url) {

        preg_match('/<title>(.*?)<\/title>/si', $html, $m1);
        $title = isset($m1[1]) ? trim(strip_tags($m1[1])) : '';

        preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)/i', $html, $m2);
        $desc = isset($m2[1]) ? trim($m2[1]) : '';

        if ($title === '' && $desc === '') {
            return ['ok' => false, 'error' => 'Strict mode could not extract'];
        }

        $img = self::resolve_image($html, '', '', $url);

        return [
            'ok'          => true,
            'title'       => $title,
            'content'     => $title . "\n\n" . $desc,
            'image'       => $img,
            'description' => $desc,
        ];
    }

    // ------------------------------------------------------------
    // TITLE + DESCRIPTION MODE
    // ------------------------------------------------------------
    private static function title_description_mode($html, $url) {

        preg_match('/<title>(.*?)<\/title>/si', $html, $m1);
        $title = isset($m1[1]) ? trim(strip_tags($m1[1])) : '';

        preg_match('/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)/i', $html, $m2);
        $desc = isset($m2[1]) ? trim($m2[1]) : '';

        if ($title === '' && $desc === '') {
            return ['ok' => false, 'error' => 'Cannot extract title/description'];
        }

        $img = self::resolve_image($html, '', '', $url);

        return [
            'ok'          => true,
            'title'       => $title,
            'description' => $desc,
            'image'       => $img
        ];
    }

    // ------------------------------------------------------------
    // IMAGE PRIORITY ENGINE
    // ------------------------------------------------------------
    private static function resolve_image($html, $clean_html, $meta_img, $url) {

        // 1) OG image
        if (!empty($meta_img)) {
            return self::abs_url(html_entity_decode($meta_img), $url);
        }

        // 2) Clean HTML first image
        if (!empty($clean_html) &&
            preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $clean_html, $m1)) {
            return self::abs_url(html_entity_decode($m1[1]), $url);
        }

        // 3) Fallback: raw HTML image
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $html, $m2)) {
            return self::abs_url(html_entity_decode($m2[1]), $url);
        }

        return '';
    }

    // ------------------------------------------------------------
    // FINALIZER (adds dedupe + prepares output)
    // ------------------------------------------------------------
    private static function finalize(
        $url,
        $title,
        $content,
        $image,
        $description = '',
        $keywords = '',
        $canonical = '',
        $links = []
    ) {
        $clean_title = trim(strip_tags($title));
        $clean_content = trim(strip_tags($content));

        // Content hash (first 800 chars)
        $content_hash = md5(substr($clean_content, 0, 800));

        // Image hash (download & hash only binary, no upload)
        $image_hash = '';
        if (!empty($image) && class_exists('SystemCore_Dedupe')) {
            $img = wp_remote_get($image, ['timeout' => 10]);
            if (!is_wp_error($img)) {
                $bin = wp_remote_retrieve_body($img);
                if (!empty($bin)) {
                    $image_hash = md5($bin);
                }
            }
        }

        // Register dedupe record
        if (class_exists('SystemCore_Dedupe')) {
            SystemCore_Dedupe::add(
                $url,
                $clean_title,
                $content_hash,
                $image_hash,
                0,
                'scraper'
            );
        }

        if (class_exists('SystemCore_Logger')) {
            SystemCore_Logger::info(
                'Scraper finalize',
                'scraper',
                json_encode([
                    'url'          => $url,
                    'title_len'    => strlen($clean_title),
                    'content_len'  => strlen($clean_content),
                    'has_image'    => !empty($image),
                ])
            );
        }

        return [
            'success'     => true,
            'title'       => $clean_title,
            'content'     => $clean_content,
            'image'       => $image,
            'description' => $description,
            'canonical'   => $canonical,
            'keywords'    => $keywords,
            'links'       => $links,
            'hashes'      => [
                'content' => $content_hash,
                'image'   => $image_hash
            ],
            'error'       => ''
        ];
    }

    // ------------------------------------------------------------
    // Absolute URL builder
    // ------------------------------------------------------------
    protected static function abs_url($src, $base) {

        if (empty($src)) {
            return '';
        }

        if (parse_url($src, PHP_URL_SCHEME) || str_starts_with($src, '//')) {
            return $src;
        }

        $b = parse_url($base);
        if (!$b) return $src;

        $scheme = $b['scheme'] ?? 'https';
        $host   = $b['host']   ?? '';
        $port   = isset($b['port']) ? ':' . $b['port'] : '';
        $path   = isset($b['path']) ? $b['path'] : '/';

        if (str_starts_with($src, '/')) {
            return $scheme . '://' . $host . $port . $src;
        }

        $dir = rtrim(preg_replace('#/[^/]*$#', '/', $path), '/') . '/';
        return $scheme . '://' . $host . $port . $dir . ltrim($src, './');
    }
}
