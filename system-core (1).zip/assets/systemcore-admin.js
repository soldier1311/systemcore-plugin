jQuery(function ($) {

    /* ============================================================
     *  UNIVERSAL AJAX HANDLER
     * ============================================================ */
    function scAjax(action, data, onSuccess, onError) {
        data = data || {};
        data.action = action;
        data.nonce  = SystemCoreAdmin.nonce;

        $.post(SystemCoreAdmin.ajax_url, data)
            .done(function (resp) {
                if (resp && resp.success) {
                    if (typeof onSuccess === "function") onSuccess(resp.data);
                } else {
                    if (typeof onError === "function") onError(resp.data || resp);
                }
            })
            .fail(function (err) {
                if (typeof onError === "function") onError(err);
            });
    }

    /* ============================================================
     *  NOTICES
     * ============================================================ */
    function scShowNotice($wrap, type, message) {
        if (!$wrap.length) return;
        var html =
            '<div class="notice notice-' +
            type +
            ' is-dismissible" style="margin-top:10px;"><p>' +
            message +
            "</p></div>";
        $wrap.html(html);
    }

    /* ============================================================
     *  DASHBOARD STATS AUTO REFRESH
     * ============================================================ */
    function scLoadDashboardStats() {
        if (!$('[data-sc="total_queue"]').length) return;

        scAjax("systemcore_dashboard_stats", {}, function (data) {
            $('[data-sc="total_queue"]').text(data.total_queue);
            $('[data-sc="pending_queue"]').text(data.pending_queue);
            $('[data-sc="processed_queue"]').text(data.processed_queue);
            $('[data-sc="total_logs"]').text(data.total_logs);
            $('[data-sc="last_fetch"]').text(data.last_fetch);
            $('[data-sc="last_publish"]').text(data.last_publish);
        });
    }

    scLoadDashboardStats();


    /* ============================================================
     *  FETCH NOW
     * ============================================================ */
    $(document).on("click", ".sc-btn-fetch-now", function (e) {
        e.preventDefault();
        var $wrap = $(this).closest(".systemcore-card, .sc-card").find(".sc-notice-area").first();
        scShowNotice($wrap, "info", "Running fetch...");

        scAjax(
            "systemcore_fetch_now",
            {},
            function (data) {
                scShowNotice($wrap, "success", data.message || "Fetch completed.");
                scLoadDashboardStats();
                setTimeout(() => location.reload(), 1000);
            },
            () => scShowNotice($wrap, "error", "Failed to run fetch.")
        );
    });


    /* ============================================================
     *  PUBLISH NOW
     * ============================================================ */
    $(document).on("click", ".sc-btn-publish-now", function (e) {
        e.preventDefault();
        var $wrap = $(this).closest(".systemcore-card, .sc-card").find(".sc-notice-area").first();
        scShowNotice($wrap, "info", "Publishing...");

        scAjax(
            "systemcore_manual_publish",
            {},
            function (data) {
                scShowNotice($wrap, "success", data.message || "Publish completed.");
                scLoadDashboardStats();
                setTimeout(() => location.reload(), 1000);
            },
            (err) => scShowNotice($wrap, "error", err.message || "Error")
        );
    });


    /* ============================================================
     *  QUEUE SYSTEM
     * ============================================================ */
    function scRenderPagination($wrap, page, totalPages) {
        $wrap.empty();
        if (totalPages <= 1) return;

        for (let p = 1; p <= totalPages; p++) {
            let $btn = $('<button class="button button-secondary"></button>')
                .text(p)
                .data("page", p);
            if (p === page) $btn.addClass("button-primary");
            $wrap.append($btn);
        }
    }

    function scLoadQueue(page) {
        let $body = $("#sc-queue-table tbody");
        if (!$body.length) return;

        page = page || 1;
        let search = $("#sc-queue-search").val() || "";

        $body.html("<tr><td colspan='6'>Loading...</td></tr>");

        scAjax("systemcore_queue_list", { page, search }, function (data) {
            $body.empty();

            if (!data.items.length) {
                $body.html("<tr><td colspan='6'>No items found.</td></tr>");
                $("#sc-queue-pagination").empty();
                return;
            }

            $.each(data.items, function (_, item) {
                let status = item.processed ? "Processed" : "Pending";

                let $row = $("<tr></tr>");
                $row.append("<td>" + item.id + "</td>");
                $row.append("<td>" + item.source + "</td>");
                $row.append('<td><a href="' + item.url + '" target="_blank">' + item.title + "</a></td>");
                $row.append("<td>" + (item.published_at || "") + "</td>");
                $row.append("<td>" + status + "</td>");

                let $actions = $("<td></td>");
                $actions.append(
                    $('<button class="button button-small sc-queue-delete">Delete</button>').data("id", item.id)
                );
                $actions.append(" ");
                $actions.append(
                    $('<button class="button button-small sc-queue-mark">Mark</button>').data("id", item.id)
                );

                $row.append($actions);
                $body.append($row);
            });

            scRenderPagination($("#sc-queue-pagination"), data.page, data.total_pages);
        });
    }

    $("#sc-queue-refresh").on("click", () => scLoadQueue(1));
    $("#sc-queue-search").on("keyup", (e) => e.keyCode === 13 && scLoadQueue(1));
    $("#sc-queue-pagination").on("click", "button", function () {
        scLoadQueue($(this).data("page"));
    });

    $("#sc-queue-table")
        .on("click", ".sc-queue-delete", function () {
            let id = $(this).data("id");
            if (!confirm("Delete this queue item?")) return;

            scAjax("systemcore_queue_delete", { id }, () => {
                scLoadQueue(1);
                scLoadDashboardStats();
            });
        })
        .on("click", ".sc-queue-mark", function () {
            let id = $(this).data("id");
            scAjax("systemcore_queue_mark_processed", { id }, () => {
                scLoadQueue(1);
                scLoadDashboardStats();
            });
        });

    scLoadQueue(1);


/* ============================================================
 *  LOGS SYSTEM — UPDATED FOR NEW BACKEND
 * ============================================================ */
function scLoadLogs() {
    let $body = $("#sc-logs-table tbody");
    if (!$body.length) return;

    $body.html("<tr><td colspan='5'>Loading...</td></tr>");

    scAjax("systemcore_logs_list", {}, function (data) {
        $body.empty();

        if (!data.items.length) {
            $body.html("<tr><td colspan='5'>No logs found.</td></tr>");
            return;
        }

        $.each(data.items, function (_, item) {

            let $row = $("<tr></tr>");

            $row.append(`<td>${item.id}</td>`);
            $row.append(`<td>${item.level}</td>`);
            $row.append(`<td>${item.context}</td>`);

            $row.append(`
                <td>
                    <div class="sc-log-message">
                        ${(item.message || "").replace(/\n/g, "<br>")}
                    </div>
                </td>
            `);

            $row.append(`<td>${item.created_at}</td>`);

            $body.append($row);
        });
    });
}

$("#sc-logs-clear").on("click", function () {
    if (!confirm("Clear all logs?")) return;

    scAjax("systemcore_logs_clear", {}, function () {
        scLoadLogs();
    });
});

// Initial load
scLoadLogs();


    /* ============================================================
     *  AI SETTINGS — ACCORDION
     * ============================================================ */
    $(document).on("click", ".sc-acc-header", function () {
        $(this).closest(".sc-acc-item").toggleClass("open");
    });


    /* ============================================================
     *  AI SETTINGS — Test API NOW
     * ============================================================ */
    function scRunApiTest(statusSel, errorSel, resultSel) {
        $(resultSel).text("Testing...").css("color", "#444");

        scAjax("systemcore_test_api_now", {}, function () {
            $(statusSel).text("Connected").removeClass("sc-error").addClass("sc-ok");
            $(errorSel).text("");
            $(resultSel).text("Connected").css("color", "green");
        }, function (err) {
            $(statusSel).text("Error").addClass("sc-error");
            $(errorSel).text(err.message || "Error");
            $(resultSel).text(err.message || "Error").css("color", "red");
        });
    }

    $("#sc-test-api-btn").on("click", function () {
        scRunApiTest("#sc-api-status-text", "#sc-api-error", "#sc-test-result");
    });

    $("#sc-test-api-btn-2").on("click", function () {
        scRunApiTest("#sc-api-status-text", "#sc-api-error", "#sc-test-result-2");
    });


    /* ============================================================
     *  FEED SOURCES POPUP SYSTEM
     * ============================================================ */
    const modal  = $("#sc-modal");
    const form   = $("#sc-source-form");

    // OPEN ADD NEW
    $("#sc-open-new-source").on("click", function () {
        $("#sc-modal-title").text("Add New Source");
        $("#sc-source-id").val(0);
        $("#sc-source-name").val("");
        $("#sc-source-url").val("");
        modal.addClass("active");
    });

    // CLOSE
    $(".sc-close-modal").on("click", function () {
        modal.removeClass("active");
    });

    // EDIT
    $(document).on("click", ".sc-btn-edit", function () {
        let id = $(this).data("id");

        scAjax("systemcore_get_feed_source", { id }, function (data) {
            $("#sc-modal-title").text("Edit Source");
            $("#sc-source-id").val(data.id);
            $("#sc-source-name").val(data.source_name);
            $("#sc-source-url").val(data.feed_url);
            modal.addClass("active");
        }, function () {
            alert("Error loading source.");
        });
    });

    // DELETE
    $(document).on("click", ".sc-btn-delete", function () {
        let id = $(this).data("id");
        if (!confirm("Delete this source?")) return;

        scAjax("systemcore_delete_feed_source", { id }, function () {
            $(`.sc-feed-item[data-id="${id}"]`).remove();
        }, function () {
            alert("Delete failed.");
        });
    });

    // SAVE ADD/EDIT
    form.on("submit", function (e) {
        e.preventDefault();

        let data = form.serialize();

        $.post(SystemCoreAdmin.ajax_url, data, function (res) {
            if (!res.success) {
                alert(res.data.message || "Error saving");
                return;
            }
            location.reload();
        });
    });

});
